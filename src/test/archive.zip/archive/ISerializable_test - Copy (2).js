'use strict';

/* Jasmine.js unit test suite for ISerializable interface in meetup even planner application
*
*  This suite designed to be able to be run as independently as possible from other tests
*  and/or functionality. UI and other integration testing is done seperately.

*/

describe('Interface ISerializable', function(){
	
	
	it('cannot be instantiated', function() {
		
		try { // this shold throw an error
			
			void new app.ISerializable();
		}
		
		catch(e) { // interfaces cannot be instantiated, so an error here is a positive outcome
		
			expect(e.message).toEqual(app.ISerializable.constructorErrorMessage);
		}
	});
	

	it('defines a className() method signature', function() {
			
		// verify that method signature exists
		
		expect(app.ISerializable.prototype.className).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.className).toBe('function');
	});
		
	
	it('throws an error if className() is invoked', function() {
			
		// verify that method invokation throws error
		
		try {
		
			app.ISerializable.prototype.className();
		}
		
		catch(e) { // a method signature cannot be invoked, so an error here is a positive outcome
		
			expect(e.message).toEqual(app.ISerializable.prototype.className.errorMessage);
		}
	});
	
	
	it('defines an id() method signature', function() {
			
		// verify that method signature exists
		
		expect(app.ISerializable.prototype.id).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.id).toBe('function');
	});
		
	
	it('throws an error if id() is invoked', function() {
			
		// verify that method invokation throws error
		
		try {
		
			app.ISerializable.prototype.id();
		}
		
		catch(e) { // a method signature cannot be invoked, so an error here is a positive outcome
		
			expect(e.message).toEqual(app.ISerializable.prototype.id.errorMessage);
		}
	});
	
	
	it('defines a toJSON() method signature', function() {
			
		// verify that method signature exists
		
		expect(app.ISerializable.prototype.toJSON).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.toJSON).toBe('function');
	});
		
	
	it('throws an error if toJSON() is invoked', function() {
			
		// verify that method invokation throws error
		
		try {
		
			app.ISerializable.prototype.toJSON();
		}
		
		catch(e) { // a method signature cannot be invoked, so an error here is a positive outcome
		
			expect(e.message).toEqual(app.ISerializable.prototype.toJSON.errorMessage);
		}
	});
	
	
	it('defines an onDeserialized() method signature', function() {
			
		// verify that method signature exists
		
		expect(app.ISerializable.prototype.onDeserialized).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.onDeserialized).toBe('function');
	});
		
	
	it('throws an error if onDeserialized() is invoked', function() {
			
		// verify that method invokation throws error
		
		try {
		
			app.ISerializable.prototype.onDeserialized();
		}
		
		catch(e) { // a method signature cannot be invoked, so an error here is a positive outcome
		
			expect(e.message).toEqual(app.ISerializable.prototype.onDeserialized.errorMessage);
		}
	});
	
	
	it('defines a default parseParams method', function() {
		
		expect(app.ISerializable.prototype.default_parseParams).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.default_parseParams).toBe('function');
	});
	
	
	xit('(more parseParams tests here!)', function() {
		
		
	});
	
	describe('when interacting with localStorage', function() {
		
		var testObj, oldPermission;
		
		beforeEach(function() {
			
			app.TestClass = function() {
				
				var _className = 'TestClass', _id = 100, a = 2, b = 'one';
				
				this.className = function() {return _className;};
				
				this.id = function(id) {if(id) {_id = id;} return _id;};
				
				app.TestClass.prototype.toJSON = function() {return {_className: _className, _id: _id, a: a, b: b}};
				
				this.default_writeObject = app.ISerializable.prototype.default_writeObject;
				
				this.default_readObject = app.ISerializable.prototype.default_readObject;
				
				this.default_removeObject = app.ISerializable.prototype.default_removeObject;
			};
			
			testObj = new app.TestClass();
			
			oldPermission = app.prefs.localStorageAllowed();
			
			app.prefs.localStorageAllowed(true);
		});
		
		
		it('defines a default writeObject method', function() {
		
			expect(app.ISerializable.prototype.default_writeObject).toBeDefined();
			
			expect(typeof app.ISerializable.prototype.default_writeObject).toBe('function');
		});
		
		
		it('can write an object to local storage', function() {
			
			testObj.default_writeObject();
			
			expect(localStorage.getItem(app.prefs.localStoragePrefix() + 'TestClass.100')).toBe('{"_className":"TestClass","_id":100,"a":2,"b":"one"}');
		});
		
		
		it('rejects attempt to write object unless permission to do so is clear from prefs', function() {
			
			app.prefs.localStorageAllowed(false);
			
			try {
				
				testObj.default_writeObject();
			}
			
			catch(e) {
				
				expect(e.message).toBe('Use of local storage not allowed by user');
			}
			
			expect(true).toBe(true); // Jasmine.js may not see expect()s in trys
		});
		
		
		it('rejects attempt to write an object not spefifying a valid class to local storage', function() {
			
			app.TestClass.className = 'not a function';
			
			try {
			
				testObj.default_writeObject();
			}
			
			catch(e) {
			
				expect(e.message).toBe('this.className is not a function');
			}
			
			expect(true).toBe(true); // Jasmine.js may not see expect()s in trys
		});
		
		
		it('rejects attempt to write an object containing circular reference to local storage', function() {
			
			app.TestClass.prototype.toJSON = function() {var a = {}, b = {a: a}; a.b = b; return a};
			
			try { // normal object circularity
			
				testObj.default_writeObject();
			}
			
			catch(e) {
			
				expect(e.message).toBe('Converting circular structure to JSON');
			}
			
			app.TestClass.prototype.toJSON = function() {return {t:this}};
			
			try { // reference to 'this'
			
				testObj.default_writeObject();
			}
			
			catch(e) {
			
				expect(e.message).toBe('Maximum call stack size exceeded');
			}
			
			expect(true).toBe(true); // Jasmine.js may not see expect()s in trys
		});
		
		
		it('defines a default readObject method', function() {
			
			expect(app.ISerializable.prototype.default_readObject).toBeDefined();
			
			expect(typeof app.ISerializable.prototype.default_readObject).toBe('function');
		});
		
		
		it('can accurately retrieve an object from local storage', function() {
			
			testObj.default_writeObject();
			
			var obj = testObj.default_readObject();
			
			expect(obj._className).toBe('TestClass');
			
			expect(obj._id).toBe(100);
			
			expect(obj.a).toBe(2);
			
			expect(obj.b).toBe('one');
			
			expect(JSON.stringify(testObj).split('').sort().join()).toEqual(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('returns null if attempting to read object that does not exist from local storage', function() {
			
			testObj.id(101);
			
			var obj = testObj.default_readObject();
			
			expect(obj).toBe(null);
		});
		
		
		it('defines a default removeObject method', function() {
			
			expect(app.ISerializable.prototype.default_removeObject).toBeDefined();
			
			expect(typeof app.ISerializable.prototype.default_removeObject).toBe('function');
		});
		
		
		it('can accurately remove an object from local storage', function() {
			
			testObj.default_writeObject();
			
			var test2 = new app.TestClass(); test2.id(101);test2.default_writeObject();
			
			var test3 = new app.TestClass(); test3.id(102);test3.default_writeObject();
			
			expect(localStorage.length).toBe(3);
			
			
			test2.default_removeObject();
			
			expect(test2.default_readObject()).toBe(null);
			
			expect(localStorage.length).toBe(2);
		});
		
		
		afterEach(function() {
			
			delete app.TestClass;
			
			localStorage.clear();
			
			app.prefs.localStorageAllowed(oldPermission);
		});
	});
	
	
});