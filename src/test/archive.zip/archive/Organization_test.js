'use strict';

/* Jasmine.js unit test suite for Organization class in meetup even planner application
*
*  This suite designed to be able to be run as independently as possible from other tests
*  and/or functionality. UI and other integration testing is done seperately.

*/

describe('class Organization', function(){
	
	it('implements the IHost interface', function() { //uses Interface.js
			
			expect(app.InterfaceTester.isImplementationOf(app.Organization, app.IHost)).toBe(true);
	});
	
	
	it('implements the ISerializable interface', function() { // uses Interface.js
		
			expect(app.InterfaceTester.isImplementationOf(app.Organization, app.ISerializable)).toBe(true);
	});
		
		
	it('can be instantiated with no parameters', function() {
		
		expect((new app.Organization()).constructor).toBe(app.Organization);
	});
	
	
	it('can be instantiated with the organization\'s name as a parameter', function() {
		
		expect((new app.Organization('ACME')).name()).toBe('ACME');
	});
	
	
	it('can re-instantiate from a JSON object', function() {
		
		var testOrg = new app.Organization();
		
		app.Organization.registry.remove(testOrg); // else we get duplication error when new instance tries to insert itself into registry during construction
		
		expect(new app.Organization(JSON.parse(JSON.stringify(testOrg))).id()).toEqual(testOrg.id());
	});
	
	
	it('rejects attempt to re-instantiate from JSON with the wrong class', function() {
		
		try {
			
			this.success = new app.Email({_className: 'NotOrganization'});
		}
		
		catch(e) {
			
			expect(e.message.indexOf('Wrong constructor')).toBe(0);
		}
		
		expect(this.success).not.toBeDefined();
	});
	
	
	it('rejects attempt to re-instantiate from JSON missing non-zero integer ID', function() {
		
		try {
			
			this.success = new app.Organization({_className: 'Organization'});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		
		try {
			
			this.success = new app.Organization({_className: 'Organization', _id: 'not an integer'});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		
		try {
			
			this.success = new app.Organization({_className: 'Organization', _id: -1});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		expect(this.success).not.toBeDefined();
	});
	
	
	it('has an object registry', function() {
		
		expect(app.Organization.registry.constructor).toBe(app.ObjectRegistry);
		
		expect(app.Organization.registry.type()).toBe(app.Organization);
	});
	
	
	describe('Organization instance', function() {
		
		var testOrg, oldPermission;
		
		beforeEach(function() {
			
			testOrg = new app.Organization();
			
			oldPermission = app.prefs.localStorageAllowed();
			
			app.prefs.localStorageAllowed(true);
		});
		
		
		it('can get its ID', function() {
		
			expect(testOrg.id()).toBeDefined();
		});
		
		
		it('rejects attempt to set ID (b/c read-only', function() {
		
			try {
				
				testOrg.id(5);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Illegal parameter: id is read-only');
			}
		});
		
				
		it('has an ID that is a positive integer or zero', function() {
		
			expect(testOrg.id()).toBeGreaterThan(-1);
			
			expect(parseInt(testOrg.id()) === testOrg.id()).toBe(true);
		});
		
		
		it('can set and get its name', function() {
		
			testOrg.name('testName');
			
			expect(testOrg.name()).toBe('testName');
		});
		
		
		it('can set and get its IHost hostName', function() { //uses Interface.js
			
			testOrg.hostName('testHostName');
			
			expect(testOrg.hostName()).toBe('testHostName');
		});
		
		
		it('can serialize its data to a valid JSON string', function() {
			
			var obj = JSON.parse(JSON.stringify(testOrg));
			
			expect(typeof obj).toBe('object');
			
			expect(obj._className).toBeDefined();
			
			expect(obj._id).toBeDefined();
			
			expect(obj._name).toBeDefined();
		});
		
		
		it('can write itself to local storage', function() {
			
			testOrg.writeObject();
			
			var obj = JSON.parse(localStorage.getItem(app.prefs.localStoragePrefix() + testOrg.className() + '.' + testOrg.id()));
			
			expect(testOrg.className()).toEqual(obj._className);
			
			expect(testOrg.id()).toEqual(obj._id);
			
			expect(JSON.stringify(testOrg).split('').sort().join()).toBe(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('can read itself from local storage', function() {
			
			testOrg.writeObject();
			
			var obj = testOrg.readObject();
			
			expect(testOrg.className()).toEqual(obj._className);
			
			expect(testOrg.id()).toEqual(obj._id);
			
			expect(JSON.stringify(testOrg).split('').sort().join()).toBe(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('can remove itself from local storage', function() {
			
			testOrg.writeObject();
			
			expect(testOrg.readObject()).toBeDefined();
			
			testOrg.removeObject();
			
			expect(testOrg.readObject()).toBe(null);
			
		});
		
		
		it('can be deserialized from a JSON string in local storage back into an instance of the class', function() {
			
			testOrg.name('Cool Coders'); // set a value to test for
			
			testOrg.writeObject(); // write out to local storage
			
			app.Organization.registry = new app.ObjectRegistry(app.Organization, 'Organization'); // reset registry
			
			expect(Object.keys(app.Organization.registry.getObjectList()).length).toBe(0); // confirm that we're empty
			
			testOrg = new app.Organization(testOrg.id()); // re-instantiate from local storage
			
			expect(testOrg.className()).toBe('Organization'); // test
			
			expect(testOrg.name()).toBe('Cool Coders');
		});
		
		
		/*
		it('can be deserialized from a JSON object back into an instance of the class', function() {
			
			app.Organization.registry = new app.ObjectRegistry(app.Organization); // reset registry
			
			expect(app.Organization.registry.getObjectList()).toEqual({}); // confirm that we're empty
			
			void new app.Organization('ACME');
			
			void new app.Organization('Big Corp');
			
			void new app.Organization('Corner Shop');
			
			expect(app.Organization.registry.getObjectList()).not.toEqual({}); // check that we have some data
			
			
			var before = JSON.stringify(app.Organization.registry); // serialize accounts in registry to string
			
			app.Organization.registry = new app.ObjectRegistry(app.Organization); // reset registry
			
			expect(app.Organization.registry.getObjectList()).toEqual({}); // confirm that we're empty
			
			app.Organization.registry.processJSON(JSON.parse(before)); //parse back into JSON
			
			expect(app.Organization.registry.getObjectList()).not.toEqual({}); // check that we have some data
			
			
			expect(app.Organization.registry.getObjectById(0).name()).toBe('ACME'); // test
			
			expect(app.Organization.registry.getObjectById(1).name()).toBe('Big Corp');
			
			expect(app.Organization.registry.getObjectById(2).name()).toBe('Corner Shop');
			
			
			app.Organization.registry.onDeserialized(); //re-establish complex object references
			//no test for those yet
		});
		*/		
		
		xit('can re-establish object references when de-serializing from JSON', function(){
			
			
		});
		
		
		afterEach(function(){
			
			app.prefs.localStorageAllowed(oldPermission);
		});
		
		
		afterAll(function() {
			
			testOrg = null;
		});
		
	});
	
});