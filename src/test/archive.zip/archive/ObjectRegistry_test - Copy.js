'use strict';

/* Jasmine.js unit test suite for ObjectRegistry class in meetup even planner application
*
*  The purpose of the class is to perform compiler-like checking of the implementation of an interface during unit
testing, without adding to the production code.
*/

var app = app || {};

describe('class ObjectRegistry', function(){
	
	it('can be instantiated', function() {
		
		expect((new app.ObjectRegistry(String, 'String')).constructor).toBe(app.ObjectRegistry);
	});
	
	
	describe('ObjectRegistry instance', function() {
		
		var testRegistry;
		
		app.TestType = function(val) {
			
			if (val && val._constructor_) { // parse deserialized JSON object
				
				this._id = val._id;
				
				this.attr = val.attr;
			}
			
			else {
			
				this._id = app.TestType.cnt++;
				
				this.attr = val;
			}
			
			this.id = function() {return this._id};
			
			this.toJSON = function() {
				
				return {
					
					_constructor_: 'TestType',
					
					_id: this._id,
					
					attr: this.attr
				}
			}
		};
		
		app.TestType.cnt = 0;
		
		
		beforeEach(function() {
		
			testRegistry = new app.ObjectRegistry(app.TestType, 'TestType');
			
			app.TestType.cnt = 0;
		});
		
		
		
		it('can add an object to the registry', function() {
			
			for (var i = 0; i < 25; i++) {
				
				testRegistry.add(new app.TestType());
				
				expect(testRegistry.getObjectList()[i]._id).toBe(i);
			}
		});
		
		
		it('silently rejects attempt to add an object already in the registry', function() {
			
			// First attempt, should succeed
			
			expect(testRegistry.getObjectList()[0]).not.toBeDefined();
			
			var dupl = new app.TestType();
			
			testRegistry.add(dupl);
			
			expect(testRegistry.getObjectList()[0].id()).toBe(0);
			
			
			// Second attempt, should fail silently
			
			testRegistry.add(dupl);
			
			expect(testRegistry.getObjectList()[1]).not.toBeDefined(0);
		});
		
		it('rejects attempt to add an object of the wrong type', function() {
			
			expect(testRegistry.getObjectList()[app.TestType.cnt]).not.toBeDefined();
			
			try {
				
				testRegistry.add(''); // we're expecting a app.TestType
			}
			
			catch(e) {
				
				expect(e.message).toBe('Wrong type for this registry');
			}
			
			expect(testRegistry.getObjectList()[app.TestType.cnt]).not.toBeDefined();
		});
		
		
		it('rejects attempt to add an object without an id() method returning a non-zero integer', function() {
			
			var testObj = new app.TestType();
			
		
			testObj._id = 'not an integer';
			
			try {
				
				this.success = testRegistry.add(testObj);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Object must support a id() method that returns a non-negative integer');
			}
			
			
			testObj._id = -1;
			
			try {
				
				this.success = testRegistry.add(testObj);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Object must support a id() method that returns a non-negative integer');
			}
			
			
			delete testObj.id;
			
			try {
				
				this.success = testRegistry.add(testObj);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Object must support a id() method that returns a non-negative integer');
			}
			
			expect(this.success).not.toBeDefined();
		});
		
		
		it('starts generating IDs at zero', function() {
		
			expect(testRegistry.getNextId()).toBe(0);
		});
		
		
		it('subsequently generates integer IDs that increment by 1', function() {
			
			var nextId;
			
			for (var i = 0; i < 101; i++) {
			
				nextId = testRegistry.getNextId();
				
				expect(nextId).toBe(i);
				
				expect(parseInt(nextId) === nextId).toBe(true);
				
				testRegistry.add(new app.TestType());
			}
		});
		
		
		it('can get an object from the registry by ID', function(){
			
			testRegistry.add(new app.TestType());
			
			var testObj = new app.TestType(); testRegistry.add(testObj);
			
			testRegistry.add(new app.TestType());
			
			expect(testRegistry.getObjectById(testObj.id())).toBe(testObj); // id found
			
			expect(testRegistry.getObjectById(10000)).not.toBeDefined(); // no match
		});
		
		
		it('can get an object from the registry by property value', function(){
			
			testRegistry.add(new app.TestType('first'));
			
			var testObj = new app.TestType('second'); testRegistry.add(testObj);
			
			testRegistry.add(new app.TestType('third'));
			
			expect(testRegistry.getObjectByAttribute('attr', 'second')).toBe(testObj); // public attributes
			
			expect(testRegistry.getObjectByAttribute('attr', 'second')).toBe(testObj); // private attributes (expects prop to be getter method)
			
			expect(testRegistry.getObjectByAttribute('attr', 'no such object')).toBe(null); // no match
		});
		
		
		
		it('can remove an object from the registry', function(){
			
			testRegistry.add(new app.TestType());
			
			var testObj = new app.TestType(); testRegistry.add(testObj);
			
			testRegistry.add(new app.TestType());
			
			
			expect(testRegistry.getObjectById(0)).toBeDefined();
			
			expect(testRegistry.getObjectById(1)).toBeDefined();
			
			expect(testRegistry.getObjectById(2)).toBeDefined();
			
			expect(testRegistry.remove(testObj).id()).toBe(1);
			
			expect(testRegistry.getObjectById(1)).not.toBeDefined();
		});
		
		
		it('rejects attempt to remove an object of the wrong type', function() {
			
			try {
				
				this.success = testRegistry.remove({});
			}
			
			catch(e) {
				
				expect(e.message).toBe('Wrong type for this registry');
			}
			
			expect(this.success).not.toBeDefined();
		});
		
		
		it('rejects attempt to remove an object without a getInt() method returning a non-zero integer', function() {
			
			var testObj = new app.TestType();
		
			
			testObj._id = 'not an integer';
			
			try {
				
				this.success = testRegistry.remove(testObj);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Object must support a id() method that returns a non-negative integer');
			}
			
			
			testObj._id = -1;
			
			try {
				
				this.success = testRegistry.remove(testObj);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Object must support a id() method that returns a non-negative integer');
			}
			
			
			delete testObj.id;
			
			try {
				
				this.success = testRegistry.remove(testObj);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Object must support a id() method that returns a non-negative integer');
			}
			
			expect(this.success).not.toBeDefined();
		});
		
		
		it('ignores attempts to remove an object that isn\'t in the registry', function() {
			
			expect(testRegistry.getObjectById(0)).not.toBeDefined();
			
			
			testRegistry.add(new app.TestType());
			
			testRegistry.add(new app.TestType());
			
			testRegistry.add(new app.TestType());
			
			
			expect(testRegistry.getObjectList(2)).toBeDefined();
			
			testRegistry.remove(new app.TestType());
			
			expect(testRegistry.getObjectList(0)).toBeDefined();
			
			expect(testRegistry.getObjectList(1)).toBeDefined();
			
			expect(testRegistry.getObjectList(2)).toBeDefined();
		});
		
		
		it('can return a list of objects in the registry', function() {
			
			expect(testRegistry.getObjectById(0)).not.toBeDefined();
			
			
			testRegistry.add(new app.TestType());
			
			testRegistry.add(new app.TestType());
			
			testRegistry.add(new app.TestType());
						
			
			expect(testRegistry.getObjectList()[2]).toBeDefined();
			
			expect(testRegistry.getObjectList()[3]).not.toBeDefined();
		});
			
			
		it('can return the type of objects required (by function reference)', function() {
			
			expect(testRegistry.type()).toBe(app.TestType);
		});
		
		
		it('can serialize its data into a list of valid JSON objects', function() {
			
			testRegistry.add(new app.TestType());
			
			testRegistry.add(new app.TestType());
			
			testRegistry.add(new app.TestType());
			
			
			var obj_json = JSON.parse(JSON.stringify(testRegistry)); // if this doesn's throw an error, we're fine
			
			expect(typeof obj_json).toBe('object');
		});
		
		
		it('can deserialize a list of JSON objects into instances of its type', function() {
			
			testRegistry.add(new app.TestType('one'));
			
			testRegistry.add(new app.TestType('two'));
			
			testRegistry.add(new app.TestType('three'));
			
			
			var obj_json = JSON.parse(JSON.stringify(testRegistry)); // Stringify, then convert back into JSON
			
			testRegistry = new app.ObjectRegistry(app.TestType, 'TestType'); // Reset the registry
			
			testRegistry.processJSON(obj_json); // Parse in the JSON
			
			expect(testRegistry.getObjectById(0).attr).toBe('one');
			
			expect(testRegistry.getObjectById(1).attr).toBe('two');
			
			expect(testRegistry.getObjectById(2).attr).toBe('three');
			
			expect(testRegistry.getObjectById(3)).not.toBeDefined();
			
			expect(testRegistry.getNextId()).toBeGreaterThan(2);
		});
		
		xit('rejects objects of the wrong type during deserialization of JSON', function() {
			
			
		});
		
		afterAll(function() {
			
			testRegistry = null;
			
			delete app.TestType;
		});
		
	});
});