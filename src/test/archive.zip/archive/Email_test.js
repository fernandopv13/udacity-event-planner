'use strict';

/* Jasmine.js unit test suite for Email class in meetup even planner application
*
*  This suite designed to be able to be run as independently as possible from other tests
*  and/or functionality. UI and other integration testing is done seperately.

*/

describe('class Email', function(){
	
	var testMail;
		
		beforeEach(function() {
			
			testMail = new app.Email('test@mail.suite');
		});
	
	
	it('implements the ISerializable interface', function() { // uses Interface.js
		
			expect(app.InterfaceTester.isImplementationOf(app.Email, app.ISerializable)).toBe(true);
	});
	
	
	it('can be instantiated', function() {
		
		expect((testMail).constructor).toBe(app.Email);
	});
	
	
	it('can re-instantiate from a JSON object', function() {
		
		app.Email.registry.remove(testMail); // else we get duplication error when new instance tries to insert itself into registry during construction
		
		expect((new app.Email(JSON.parse(JSON.stringify(testMail)))).id()).toEqual(testMail.id());
	});
	
	
	it('rejects attempt to re-instantiate from JSON with the wrong class', function() {
		
		try {
			
			this.test = new app.Email({_className: 'NotEmail'});
		}
		
		catch(e) {
			
			expect(e.message.indexOf('Wrong constructor')).toBe(0);
		}
		
		expect(this.test).not.toBeDefined();
	});
	
	
	it('rejects attempt to re-instantiate from JSON missing non-zero integer ID', function() {
		
		try {
			
			this.test = new app.Email({_className: 'Email'});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
			
			expect(this.test).not.toBeDefined();
		}
		
		
		try {
			
			this.test = new app.Email({_className: 'Email', _id: 'not an integer'});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
			
			expect(this.test).not.toBeDefined();
		}
		
		
		try {
			
			this.test = new app.Email({_className: 'Email', _id: -1});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
			
			expect(this.test).not.toBeDefined();
		}
	});
	
	
	it('has an object registry', function() {
		
		expect(app.Email.registry.constructor).toBe(app.ObjectRegistry);
		
		expect(app.Email.registry.type()).toBe(app.Email);
	});
	
	
	describe('Email instance', function() {
		
		var testMail, oldPermission;
		
		beforeEach(function() {
			
			testMail = new app.Email('test@mail.suite');
			
			oldPermission = app.prefs.localStorageAllowed();
			
			app.prefs.localStorageAllowed(true);
		
		});
		
		
		it('can get its ID', function() {
		
			expect(testMail.id()).toBeDefined();
		});
		
		
		it('rejects attempt to set ID (b/c read-only', function() {
		
			try {
				
				testMail.id(5);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Illegal parameter: id is read-only');
			}
		});
		
				
		it('has an ID that is a positive integer or zero', function() {
		
			expect(testMail.id()).toBeGreaterThan(-1);
			
			expect(parseInt(testMail.id()) === testMail.id()).toBe(true);
		});
		
		
		it('can set and get its address', function() {
		
			testMail.address('name@server.domain');
			
			expect(testMail.address()).toBe('name@server.domain');
		});
		
		
		it('can validate its address without creating false negatives', function() {
			
			var tests = com_github_dominicsayers_isemail.tests;
			
			// Exluding test cases which are so exotic, refusing them seems to be an acceptable risk
			
			var exclusions = [1,5,66,67,68,69,70,71,72,73,74,75,76,77,85,86,112,115,116,117,120,121,159,166];
			
			for (var test in tests) {
				
				if (tests[test].category !== 'ISEMAIL_ERR' && exclusions.indexOf(parseInt(test)) === -1) {
					
					//if (!(new app.Email(tests[test].address)).isValid()) {console.log(test);} //debug
					
						expect((new app.Email(tests[test].address)).isValid()).toBe(true);
				}
			}
		});
		
		it('can manually override the address validation logic', function() {
			
			testMail.address('not a valid email address');
			
			expect(testMail.isValid()).toBe(false);
			
			testMail.isValid(true);
			
			expect(testMail.isValid()).toBe(true);
		});
		
		
		it('can reset manual override of the address validation logic', function() {
			
			testMail.isValid(false);
			
			expect(testMail.isValid()).toBe(false);
			
			testMail.isValid(null);
			
			expect(testMail.isValid()).toBe(true);
		});
		
		
		it('resets the validation logic when assigned a new address', function() {
			
			testMail.isValid(true);
			
			expect(testMail.isValid()).toBe(true);
			
			testMail.address('not a valid email address');
			
			expect(testMail.isValid()).toBe(false);
		});
		
		
		it('rejects attempt to invoke isValid with a non-Boolean parameter', function() {
			
			try {
				
				testMail.isValid('not a boolean');
			}
			
			catch(e) {
				
				expect(e.message).toBe('Parameter must be Boolean or null');
			}
		});
		
		
		it('can tell if its address\' validity or otherwise has been confirmed', function() {
			
			expect(testMail.isConfirmed()).toBe(false);
			
			testMail.isValid(true);
			
			expect(testMail.isConfirmed()).toBe(true);
			
			testMail.isValid(false);
			
			expect(testMail.isConfirmed()).toBe(true);
		});
		
		
		it('can be serialized to a valid JSON string', function() {
			
			var obj = JSON.parse(JSON.stringify(testMail));
			
			expect(typeof obj).toBe('object');
			
			expect(obj._className).toBeDefined();
			
			expect(obj._id).toBeDefined();
			
			expect(obj._address).toBeDefined();
			
			expect(obj._valid).toBeDefined();
		});
		
		
		it('can write itself to local storage', function() {
			
			testMail.writeObject();
			
			var obj = JSON.parse(localStorage.getItem(app.prefs.localStoragePrefix() + testMail.className() + '.' + testMail.id()));
			
			expect(testMail.className()).toEqual(obj._className);
			
			expect(testMail.id()).toEqual(obj._id);
			
			expect(JSON.stringify(testMail).split('').sort().join()).toBe(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('can read itself from local storage', function() {
			
			testMail.writeObject();
			
			var obj = testMail.readObject();
			
			expect(testMail.className()).toEqual(obj._className);
			
			expect(testMail.id()).toEqual(obj._id);
			
			expect(JSON.stringify(testMail).split('').sort().join()).toBe(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('can remove itself from local storage', function() {
			
			testMail.writeObject();
			
			expect(testMail.readObject()).toBeDefined();
			
			testMail.removeObject();
			
			expect(testMail.readObject()).toBe(null);
			
		});
		
		
		it('can be deserialized from a JSON string in local storage back into an instance of the class', function() {
			
			testMail.address('user@server.domain'); // set a value to test for
			
			testMail.writeObject(); // write out to local storage
			
			app.Email.registry = new app.ObjectRegistry(app.Email, 'Email'); // reset registry
			
			expect(Object.keys(app.Email.registry.getObjectList()).length).toBe(0); // confirm that we're empty
			
			testMail = new app.Email(testMail.id()); // re-instantiate from local storage
			
			expect(testMail.className()).toBe('Email'); // test
			
			expect(testMail.address()).toBe('user@server.domain');
		});
		
		/*
		it('can be deserialized from a JSON object back into an instance of the class', function() {
			
			app.Email.registry = new app.ObjectRegistry(app.Email); // reset registry
			
			expect(app.Email.registry.getObjectList()).toEqual({}); // confirm that we're empty
			
			void new app.Email('name1@noserver.nodomain');
			
			void new app.Email('name2@noserver.nodomain');
			
			void new app.Email('name3@noserver.nodomain');
			
			expect(app.Email.registry.getObjectList()).not.toEqual({}); // check that we have some data
			
			
			var before = JSON.stringify(app.Email.registry); // serialize accounts in registry to string
			
			app.Email.registry = new app.ObjectRegistry(app.Email); // reset registry
			
			expect(app.Email.registry.getObjectList()).toEqual({}); // confirm that we're empty
			
			app.Email.registry.processJSON(JSON.parse(before)); //parse back into JSON
			
			expect(app.Email.registry.getObjectList()).not.toEqual({}); // check that we have some data
			
			
			expect(app.Email.registry.getObjectById(0).address()).toBe('name1@noserver.nodomain'); // test
			
			expect(app.Email.registry.getObjectById(1).address()).toBe('name2@noserver.nodomain');
			
			expect(app.Email.registry.getObjectById(2).address()).toBe('name3@noserver.nodomain');
			
			
			app.Email.registry.onDeserialized(); //re-establish complex object references
			//no test for those yet
		});
		*/
		
		xit('can re-establish object references when de-serializing from JSON', function(){
			
			
		});
		
		afterEach(function() {
			
			app.prefs.localStorageAllowed(oldPermission);
		});
		
		
		afterAll(function() {
			
			testMail = null;
		});
		
	});
	
});