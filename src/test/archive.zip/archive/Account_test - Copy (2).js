'use strict';

/* Jasmine.js unit test suite for javascript pseuado-classical class template */

describe('class Account', function(){
	
	app.Email = app.Email || function() {};
			
	
	it('implements the ISerializable interface', function() { // uses Interface.js
		
			expect(app.InterfaceTester.isImplementationOf(app.Account, app.ISerializable)).toBe(true);
	});
	
	
	it('can be instantiated', function() {
		
		expect((new app.Account(new app.Email(), 'Abcd!123')).constructor).toBe(app.Account);
	});
	
	
	it('rejects attempt to create with an email that is not an Email', function() {
			
		try {
			
			this.success = new app.Account('Not an Email', 'Abcd!123');
		}
		
		catch(e) {
			
			expect(e.message).toBe('Wrong type: Email must be an instance of the Email class');
		}
		
		expect(this.success).not.toBeDefined();
	});
	
	
	it('rejects attempt to create with an insecure password', function() {
			
		try {
			
			this.success = new app.Account(new app.Email(), 'Abcd123');
		}
		
		catch(e) {
			
			expect(e.message).toBe('Invalid password: Passwords must be at least min. 8 chars long and have at least one each of uppercase, lowercase and non-alpha character');
		}
		
		expect(this.success).not.toBeDefined();
	});
	
	
	it('can re-instantiate from a JSON object', function() {
		
		var testAccount = new app.Account(new app.Email('name@server.domain'), 'abcd2!_Efgh');
		
		expect(new app.Account(JSON.parse(JSON.stringify(testAccount))).id()).toEqual(testAccount.id());
		
	});
	
	
	it('rejects attempt to re-instantiate from JSON with the wrong class', function() {
		
		try {
			
			this.test = new app.Account({_className: 'NotAccount'});
		}
		
		catch(e) {
			
			expect(e.message.indexOf('Wrong constructor')).toBe(0);
		}
		
		expect(this.test).not.toBeDefined();
		
	});
	
	
	it('rejects attempt to re-instantiate from JSON missing non-zero integer ID', function() {
		try {
			
			this.test = new app.Account({_className: 'Account'});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		
		try {
			
			this.test = new app.Account({_className: 'Account', _id: 'not an integer'});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		
		try {
			
			this.test = new app.Account({_className: 'Account', _id: -1});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		expect(this.test).not.toBeDefined();
	});
	
	
	it('has an object registry', function() {
		
		expect(app.Account.registry.constructor).toBe(app.ObjectRegistry);
		
		expect(app.Account.registry.type()).toBe(app.Account);
	});
	
	
	describe('Account instance', function() {
		
		var testAccount, oldPermission;
		
		
		beforeEach(function(){
			
			testAccount = new app.Account();
			
			oldPermission = app.prefs.localStorageAllowed();
			
			app.prefs.localStorageAllowed(true);
		});
		
		
		it('can get its ID', function() {
		
			expect(testAccount.id()).toBeDefined();
		});
		
		
		it('rejects attempt to set ID (b/c read-only', function() {
		
			try {
				
				testAccount.id(5);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Illegal parameter: id is read-only');
			}
		});
		
				
		it('has an ID that is a positive integer or zero', function() {
		
			expect(testAccount.id()).toBeGreaterThan(-1);
			
			expect(parseInt(testAccount.id()) === testAccount.id()).toBe(true);
		});
		
		
		it('can set and get its email', function() {
		
			testAccount.email(new app.Email('test@noserver.nodomain'));
			
			expect(testAccount.email().address()).toBe('test@noserver.nodomain');
		});
		
		
		it('rejects attempt to set an email that is not of class Email', function() {
			
			try {
				
				testAccount.email('Not an Email');
			}
			
			catch(e) {
				
				expect(e.message).toBe('Wrong type: Email must be an instance of the Email class');
			}
			
			expect(testAccount.email()).not.toBeDefined();
		});
		
		it('can set and get its password', function() {
		
			testAccount.password('1!fghDwe');
			
			expect(testAccount.password()).toBe('1!fghDwe');
		});
		
		
		it('rejects attempt to set an insecure password', function() {
			
			try {
				
				testAccount.password('insecure');
			}
			
			catch(e) {
				
				expect(e.message).toBe('Invalid password: Passwords must be at least min. 8 chars long and have at least one each of uppercase, lowercase and non-alpha character');
			}
			
			expect(testAccount.password()).not.toBeDefined();
		});
		
		
		it('can be serialized to a valid JSON string', function() {
			
			var obj = JSON.parse(JSON.stringify(testAccount));
			
			expect(typeof obj).toBe('object');
			
			expect(obj._className).toBeDefined();
			
			expect(obj._id).toBeDefined();
			
			expect(obj._email).toBeDefined();
			
			expect(obj._password).toBeDefined();
		});
		
		
		it('can write itself to local storage', function() {
			
			testAccount.writeObject();
			
			var obj = JSON.parse(localStorage.getItem(app.prefs.localStoragePrefix() + testAccount.className() + '.' + testAccount.id()));
			
			expect(testAccount.className()).toEqual(obj._className);
			
			expect(testAccount.id()).toEqual(obj._id);
			
			expect(JSON.stringify(testAccount).split('').sort().join()).toBe(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('can read itself from local storage', function() {
			
			testAccount.writeObject();
			
			var obj = testAccount.readObject();
			
			expect(testAccount.className()).toEqual(obj._className);
			
			expect(testAccount.id()).toEqual(obj._id);
			
			expect(JSON.stringify(testAccount).split('').sort().join()).toBe(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('can remove itself from local storage', function() {
			
			testAccount.writeObject();
			
			expect(testAccount.readObject()).toBeDefined();
			
			testAccount.removeObject();
			
			expect(testAccount.readObject()).toBe(null);
			
		});
		
		
		it('can be deserialized from a JSON object back into an instance of the class', function() {
			
			app.Account.registry = new app.ObjectRegistry(app.Account, 'Account'); // reset registry
			
			expect(app.Account.registry.getObjectList()).toEqual({}); // confirm that we're empty
			
			app.Account.registry.add(new app.Account(new app.Email(), 'Pass_word1'));
			
			app.Account.registry.add(new app.Account(new app.Email(), 'Pass_word2'));
			
			app.Account.registry.add(new app.Account(new app.Email(), 'Pass_word3'));
			
			expect(app.Account.registry.getObjectList()).not.toEqual({}); // check that we have some data
			
			var before = JSON.stringify(app.Account.registry); // serialize accounts in registry to string
			
			app.Account.registry = new app.ObjectRegistry(app.Account, 'Account'); // reset registry
			
			expect(app.Account.registry.getObjectList()).toEqual({}); // confirm that we're empty
			
			app.Account.registry.processJSON(JSON.parse(before)); //parse back into JSON
			
			expect(app.Account.registry.getObjectList()).not.toEqual({}); // check that we have some data
			
			
			expect(app.Account.registry.getObjectById(0).password()).toBe('Pass_word1'); // test
			
			expect(app.Account.registry.getObjectById(1).password()).toBe('Pass_word2');
			
			expect(app.Account.registry.getObjectById(2).password()).toBe('Pass_word3');
			
			
			app.Account.registry.onDeserialized(); //re-establish complex object references
			//no test for those yet
		});
		
		
		xit('can re-establish object references when de-serializing from JSON', function(){
			
			
		});
		
		
		afterEach(function() {
			
			app.prefs.localStorageAllowed(oldPermission);
		});
		
		
		afterAll(function() {
			
			testAccount = null;
		});
	});
});