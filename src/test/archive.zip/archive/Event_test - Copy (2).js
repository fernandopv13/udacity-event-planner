'use strict';

/* Jasmine.js unit test suite for Event class in meetup even planner application
*
*  This suite designed to be able to be run as independently as possible from other tests
*  and/or functionality. UI and other integration testing is done seperately.

*/

describe('class Event', function(){
	
	var testEvent, testOrg, testPerson;
	
	{ // Set up some mocks
		
		app.Person = app.Person || function(str_name) {
			
			var _name = str_name;
			
			this.name = function(){return _name};
			
			this.id = function(){return 1};
		};
		
		app.Organization = app.Organization || function(str_name) {
			
			var _name = str_name;
			
			this.name = function(){return _name};
			
			this.id = function(){return 1};
			
			this.hostName = function() {return _name}; //need to exist for IHost related unit tests to pass
			
			this.hostName = function(name) {_name = name}; //need to exist for IHost related unit tests to pass
		};
		
		
		beforeEach(function() {
			
			testOrg = new app.Organization('test organization');
						
			testPerson = new app.Person('test event');
			
			testEvent = new app.Event(
		
				'Vinter solstice celebration',
				
				'Mood enhancer',
				
				new Date(),
				
				new Date(),
				
				'Camp Muddy',
				
				'We\'ll meet around a bonfire and keep warm with booze and tall tales under the open sky.',
				
				testOrg,
				
				500
			);
		});
	}


	it('implements the ISerializable interface', function() { // uses Interface.js
		
			expect(app.InterfaceTester.isImplementationOf(app.Event, app.ISerializable)).toBe(true);
	});
		
	
	it('can be instantiated with no parameters', function() {
		
		expect((new app.Event()).constructor).toBe(app.Event);
	});
	

	it('can be instantiated with the event\'s name as a parameter', function() {
		
		expect((new app.Event('Paaaartie!')).name()).toBe('Paaaartie!');
	});
	

	it('can be instantiated with a full set of parameters', function() {
		
		expect(testEvent.type()).toBe('Mood enhancer');
	});

	
	it('can re-instantiate from a JSON object', function() {
		
		//expect(new app.Event(JSON.parse(((testEvent).stringify()))).id()).toEqual(testEvent.id());
		expect(new app.Event(JSON.parse(JSON.stringify(testEvent))).id()).toEqual(testEvent.id());
	});
	
	
	it('rejects attempt to re-instantiate from JSON with the wrong class', function() {
		
		try {
			
			this.test = new app.Event({_className: 'NotEvent'});
		}
		
		catch(e) {
			
			expect(e.message.indexOf('Wrong constructor')).toBe(0);
		}
		
		expect(this.test).not.toBeDefined();
	});
	
	
	it('rejects attempt to re-instantiate from JSON missing non-zero integer ID', function() {
		
		try {
			
			this.test = new app.Event({_className: 'Event'});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		
		try {
			
			this.test = new app.Event({_className: 'Event', _id: 'not an integer'});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		
		try {
			
			this.test = new app.Event({_className: 'Event', _id: -1});
		}
		
		catch(e) {
			
			expect(e.message).toBe('Cannot re-instantiate object: ID not defined or not valid');
		}
		
		expect(this.test).not.toBeDefined();
	});
	
	
	it('has an object registry', function() {
		
		expect(app.Event.registry.constructor).toBe(app.ObjectRegistry);
		
		expect(app.Event.registry.type()).toBe(app.Event);
	});
	
	
	describe('Event instance', function() {
		
		var oldPermission;
		
		beforeEach(function() {
			
			oldPermission = app.prefs.localStorageAllowed();
			
			app.prefs.localStorageAllowed(true);
		});
		
		
		it('can get its ID', function() {
		
			expect((new app.Event()).id()).toBeDefined();
		});
		
		
		it('rejects attempt to set ID (b/c read-only)', function() {
		
			try {
				
				(new app.Event()).id(5);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Illegal parameter: id is read-only');
			}
		});
		
			
		it('has an ID that is a positive integer or zero', function() {
		
			expect(testEvent.id()).toBeGreaterThan(-1);
			
			expect(parseInt(testEvent.id()) === testEvent.id()).toBe(true);
		});
		
		
		it('can set and get its name', function() {
		
			testEvent.name('testName');
			
			expect(testEvent.name()).toBe('testName');
		});
		
		
		it('can set and get its type', function() {
		
			testEvent.type('testType');
			
			expect(testEvent.type()).toBe('testType');
		});
		
		
		it('can set and get its start date and time (using Date)', function() {
		
			var testDate = new Date();
			
			testEvent.start(testDate);
			
			expect(testEvent.start()).toBe(testDate);
		});
		
		it('can set and get its start date and time (using string)', function() {
		
			var testDate = new Date().toString();
			
			testEvent.start(testDate);
			
			expect(testEvent.start().toString()).toBe(testDate);
		});
		
		it('rejects attempt to set start that is not a valid Date (object or string)', function() {
		
			var oldDate = testEvent.start();
			
			var testDate = 'not a valid date (object or string)';
			
			try { // this should throw error
				
				testEvent.start(testDate);
			}
			
			catch(e)
			{
				
				expect(e.message).toBe('Start must be Date');
			}
			
			expect(testEvent.start()).toEqual(oldDate);
		});
		
		
		it('can set and get its end date and time (using Date)', function() {
		
			var testDate = new Date();
			
			testEvent.end(testDate);
			
			expect(testEvent.end()).toBe(testDate);
		});
		
		
		it('can set and get its end date and time (using string)', function() {
		
			var testDate = new Date().toString();
			
			testEvent.end(testDate);
			
			expect(testEvent.end().toString()).toBe(testDate);
		});
		
		it('rejects attempt to set end that is not a valid Date (object or string)', function() {
		
			var oldDate = testEvent.start();
			
			var testDate = 'not a valid Date (object or string)';
			
			try { // this should throw error
				
				testEvent.end(testDate);
			}
			
			catch(e)
			{
				
				expect(e.message).toBe('End must be Date');
			}
			
			expect(testEvent.end()).toEqual(oldDate);
		});

		
		it('can set and get its capacity (i.e. max no of guests)', function() {
		
			testEvent.capacity(100);
			
			expect(testEvent.capacity()).toBe(100);
		});
		
		
		it('rejects attempt to set capacity that is a not a positive integer, or zero', function() {
			
			try {
				
				testEvent.capacity('not an integer');
			}
			
			catch(e) {
				
				expect(e.message).toBe('Capacity must be an integer');
			}
			
			try {
				
				testEvent.capacity(-55);
			}
			
			catch(e) {
				
				expect(e.message).toBe('Capacity cannot be negative');
			}
		});
		
		it('can add a Person to the guest list, and check if a person is already on the list', function(){
			
			if (!testEvent.isGuest(testPerson)) {testEvent.addGuest(testPerson)}
			
			expect(testEvent.isGuest(testPerson)).toBe(true);
		});
		
		
		it('rejects attempt to add a guest that is not a Person', function() {
			
			var oldLen = testEvent.guestList().length;
			
			try {
				
				testEvent.addGuest('not a Person instance');
			}
			
			catch(e) {
				
				expect(e.message).toBe('Guest must be Person');
			}
			
			expect(testEvent.guestList().length).toEqual(oldLen);
		});
		
		
		it('rejects attempt to add guests beyond capacity', function() {
			
			testEvent.capacity(0);
			
			try {
				
				testEvent.addGuest(new app.Person('One too many'));
			}
			
			catch(e) {
				
				expect(e.message).toBe('Cannot add guests beyond capacity');
			}
		});
		
		
		it('can get a copy of the guest list', function(){
			
			testEvent.addGuest(new app.Person('One more guest'));
			
			var guestList = testEvent.guestList();
			
			expect(guestList.constructor).toBe(Array);
			
			expect(guestList[0].constructor).toBe(app.Person);
		});
		
		
		it('can remove a Person from the guest list', function(){
			
			var newGuest = new app.Person('One more guest');
			
			testEvent.addGuest(newGuest);
			
			var removed = testEvent.removeGuest(newGuest);
			
			expect(removed.constructor).toBe(Array);
			
			expect(removed.length).toEqual(1);
			
			expect(removed[0].id()).toEqual(newGuest.id());
			
		});
		
		
		it('rejects attempt to remove a guest that is not a Person', function() {
			
			var oldLen = testEvent.guestList().length;
			
			try {
				
				testEvent.removeGuest('not a Person instance');
			}
			
			catch(e) {
				
				expect(e.message).toBe('Guest must be Person');
			}
			
			expect(testEvent.guestList().length).toEqual(oldLen);
		});
		
		
		it('can set and get its location', function() {
		
			testEvent.location('testLocation');
			
			expect(testEvent.location()).toBe('testLocation');
		});
		
		
		it('can set and get its description of the event', function(){
			
			testEvent.description('testDescription');
			
			expect(testEvent.description()).toBe('testDescription');
		});
		
		
		it('can set and get its host', function(){
			
			testEvent.host(testOrg);
			
			expect(testEvent.host().hostName).toBeDefined();
		});
		
		
		it('rejects attempt to set a host that is not an IHost instance', function() {
		
			var oldHost = testEvent.host();
			
			try { // this should throw error
				
				testEvent.host({});
			}
			
			catch(e) {
				
				expect(e.message).toBe('Host must implement IHost');
			}
			
			expect(testEvent.host()).toBe(oldHost);
		});
		
		
		it('can be serialized to a valid JSON string', function() {
			
			var obj = JSON.parse(JSON.stringify(testEvent));
			
			expect(typeof obj).toBe('object');
			
			expect(obj._className).toBeDefined();
			
			expect(obj._id).toBeDefined();
			
			expect(obj._start).toBeDefined();
			
			expect(obj._end).toBeDefined();
			
			expect(obj._name).toBeDefined();
			
			expect(obj._type).toBeDefined();
			
			expect(obj._location).toBeDefined();
			
			expect(obj._description).toBeDefined();
			
			expect(obj._host).toBeDefined();
			
			expect(obj._capacity).toBeDefined();
			
			expect(obj._guests.constructor).toBe(Array);
		});
		
		
		it('can write itself to local storage', function() {
			
			testEvent.writeObject();
			
			var obj = JSON.parse(localStorage.getItem(app.prefs.localStoragePrefix() + testEvent.className() + '.' + testEvent.id()));
			
			expect(testEvent.className()).toEqual(obj._className);
			
			expect(testEvent.id()).toEqual(obj._id);
			
			expect(JSON.stringify(testEvent).split('').sort().join()).toBe(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('can read itself from local storage', function() {
			
			testEvent.writeObject();
			
			var obj = testEvent.readObject();
			
			expect(testEvent.className()).toEqual(obj._className);
			
			expect(testEvent.id()).toEqual(obj._id);
			
			expect(JSON.stringify(testEvent).split('').sort().join()).toBe(JSON.stringify(obj).split('').sort().join());
		});
		
		
		it('can remove itself from local storage', function() {
			
			testEvent.writeObject();
			
			expect(testEvent.readObject()).toBeDefined();
			
			testEvent.removeObject();
			
			expect(testEvent.readObject()).toBe(null);
			
		});
		
		
		it('can be deserialized from a JSON object back into an instance of the class', function() {
			
			// Make some extra preps for this
			
			app.Event.registry = new app.ObjectRegistry(app.Event); // reset registry
			
			app.testdata = {
	
				organizations:
				[
					new app.Organization('ACME'),
					
					new app.Organization('BigBig'),
					
					new app.Organization('Pops')
				],

				persons:
				[
					new app.Person('Peter'),
					
					new app.Person('Paul'),
					
					new app.Person('Mary')
				],

				events:
				[
					new app.Event('Web site launch party'),
					
					new app.Event('Welcome reception for Peter'),
					
					new app.Event('Friday bar')
				]
			};
			
			app.testdata.persons[0].employer(app.testdata.organizations[0]);
			app.testdata.persons[1].employer(app.testdata.organizations[1]);
			app.testdata.persons[2].employer(app.testdata.organizations[1]);
			
			app.testdata.events[0].capacity(100);
			app.testdata.events[0].addGuest(app.testdata.persons[1]);
			app.testdata.events[0].addGuest(app.testdata.persons[2]);
			app.testdata.events[0].host(app.testdata.organizations[0]);

			app.testdata.events[1].capacity(200);
			app.testdata.events[1].addGuest(app.testdata.persons[0]);
			app.testdata.events[1].addGuest(app.testdata.persons[2]);
			app.testdata.events[1].host(app.testdata.organizations[1]);

			app.testdata.events[2].capacity(25);
			app.testdata.events[2].addGuest(app.testdata.persons[0]);
			app.testdata.events[2].addGuest(app.testdata.persons[1]);
			app.testdata.events[2].host(app.testdata.organizations[2]);
			
			
			// Do the testing
			
			expect(app.Event.registry.getObjectList()).not.toEqual({}); // check that we have some data
			
			var before = JSON.stringify(app.Event.registry); // serialize events in registry to string
			
			app.Event.registry = new app.ObjectRegistry(app.Event); // reset registry
			
			expect(app.Event.registry.getObjectList()).toEqual({}); // confirm that we're empty
			
			app.Event.registry.processJSON(JSON.parse(before)); // parse back into JSON
			
			
			expect(app.Event.registry.getObjectById(0).name()).toBe('Web site launch party'); // test
			
			expect(app.Event.registry.getObjectById(1).name()).toBe('Welcome reception for Peter');
			
			expect(app.Event.registry.getObjectById(2).name()).toBe('Friday bar');
			
			expect(app.Event.registry.getObjectById(3)).not.toBeDefined();
			
			
			app.Event.registry.onDeserialized(); //re-establish complex object references
			
			expect(app.Event.registry.getObjectById(0).guestList()[1].name()).toBe('Mary'); // test complex references
			
			expect(app.Event.registry.getObjectById(1).guestList()[1].employer().name()).toBe('BigBig');
			
			expect(app.Event.registry.getObjectById(2).host().hostName()).toBe('Pops');
		});
		
		
		xit('can re-establish object references when de-serializing from JSON', function(){
			
			
		});
		
		
		xit('can render itself to a DIV', function(){
			
			
		});
		
		
		afterEach(function() {
			
			app.prefs.localStorageAllowed(oldPermission);
		});
		
		
		afterAll(function() {
			
			testEvent = null;
			
			testOrg = null;
			
			testPerson = null;
			
			delete app.testData;
		});
		
	});
	
});