'use strict';

/* Jasmine.js unit test suite for ISerializable interface in meetup even planner application
*
*  This suite designed to be able to be run as independently as possible from other tests
*  and/or functionality. UI and other integration testing is done seperately.

*/

describe('Interface ISerializable', function(){
	
	
	it('cannot be instantiated', function() {
		
		try { // this shold throw an error
			
			void new app.ISerializable();
		}
		
		catch(e) { // interfaces cannot be instantiated, so an error here is a positive outcome
		
			expect(e.message).toEqual(app.ISerializable.constructorErrorMessage);
		}
	});
	
	
	it('defines a toJSON() method signature', function() {
			
		// verify that method signature exists
		
		expect(app.ISerializable.prototype.toJSON).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.toJSON).toBe('function');
	});
		
	
	it('throws an error if toJSON() is invoked', function() {
			
		// verify that method invokation throws error
		
		try {
		
			app.ISerializable.prototype.toJSON();
		}
		
		catch(e) { // a method signature cannot be invoked, so an error here is a positive outcome
		
			expect(e.message).toEqual(app.ISerializable.prototype.toJSON.errorMessage);
		}
	});
	
	
	it('defines an onDeserialized() method signature', function() {
			
		// verify that method signature exists
		
		expect(app.ISerializable.prototype.onDeserialized).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.onDeserialized).toBe('function');
	});
		
	
	it('throws an error if onDeserialized() is invoked', function() {
			
		// verify that method invokation throws error
		
		try {
		
			app.ISerializable.prototype.onDeserialized();
		}
		
		catch(e) { // a method signature cannot be invoked, so an error here is a positive outcome
		
			expect(e.message).toEqual(app.ISerializable.prototype.onDeserialized.errorMessage);
		}
	});
	
	
	it('defines a default parseParams method', function() {
		
		expect(app.ISerializable.prototype.default_parseParams).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.default_parseParams).toBe('function');
	});
	
	
	xit('(more parseParams tests here!)', function() {
		
		
	});
	
	
	it('defines a default writeObject method', function() {
		
		expect(app.ISerializable.prototype.default_writeObject).toBeDefined();
		
		expect(typeof app.ISerializable.prototype.default_writeObject).toBe('function');
	});
	
	
	xit('can write an object to local storage', function() {
		
		app.TestClass = function() {
			
			var _id = 100, a = 2, b = 'one';
			
			this.constructor = function() {return 'TestClass';};
			
			this.id = function() {return _id;};
			
			app.TestClass.prototype.toJSON = function() {return {_id: _id, a: a, b: b}
			}
			
			this.default_writeObject = app.ISerializable.prototype.default_writeObject;
		};
		
		(new app.TestClass()).default_writeObject('TestClass');
		
		expect(localStorage.getItem(app.prefs.localStoragePrefix() + 'TestClass.100')).toBe('{"_id":100,"a":2,"b":"one"}');
		
		delete app.TestClass;
	});
	
	
	xit('rejects attempt to write an object to local storage without spefifying a valid class', function() {
		
		app.TestClass = 'no a function';
		
		try {
		
			app.ISerializable.prototype.default_writeObject({}, 'TestClass');
		}
		
		catch(e) {
		
			expect(e.message).toBe('Class must be an app property that is a function');
		}
	});
	
	
	xit('rejects attempt to write an object to local storage that will not convert to valid JSON string', function() {
		
		
	});
	
	
	xit('defines a default readObject method', function() {
		
		
	});
	
	
	xit('defines a default removeObject method', function() {
		
		
	});
});