'use strict';

/* Jasmine.js unit test suite for app object invoked by anonymous self-executing function in the style of the JS Module pattern.
*/

describe('app', function(){

	it('has been instantiated', function() {
		
		expect(app).toBeDefined();
	});
	
	
	it('has a set of preferences', function() {
		
		expect(app.prefs.constructor).toBe(Object);
	});
	
	
	it('it can get and set permission to store locally using accessor', function(){
		
		var isAllowed = app.prefs.isLocalStorageAllowed();
		
		app.prefs.isLocalStorageAllowed(!isAllowed);
		
		expect(app.prefs.isLocalStorageAllowed()).toBe(!isAllowed);
	});
	
	
	it('it cannot get and set permission to store locally without using accessor', function(){
		
		var func = app.prefs.isLocalStorageAllowed; //store the function so we can re-establish it
		
		app.prefs.isLocalStorageAllowed = true; // 'accidentally' replace function with literal
		
		try {
			
			app.prefs.isLocalStorageAllowed();
		}
		
		catch(e) {
			
			expect(e.message.indexOf('not a function')).toBeGreaterThan(-1);
		}
		
		app.prefs.isLocalStorageAllowed = func; // re-establish function
		
		expect(typeof app.prefs.isLocalStorageAllowed()).toBe('boolean'); // verify that is works again
	});
	
	
	it('it can get local storage prefix using accessor', function(){
		
		expect(app.prefs.localStoragePrefix()).toBeDefined();
		
		expect(typeof app.prefs.localStoragePrefix()).toBe('string');
	});
	
	
	it('it cannot get local storage prefix without using accessor', function(){
		
		var func = app.prefs.localStoragePrefix; //store the function so we can re-establish it
		
		app.prefs.localStoragePrefix = true; // 'accidentally' replace function with literal
		
		try {
			
			app.prefs.localStoragePrefix();
		}
		
		catch(e) {
			
			expect(e.message.indexOf('not a function')).toBeGreaterThan(-1);
		}
		
		app.prefs.localStoragePrefix = func; // re-establish function
		
		expect(typeof app.prefs.localStoragePrefix()).toBe('string'); // verify that is works again
	});
	
	
	
	it('it cannot set local storage prefix', function(){
		
		try {
			
			app.prefs.localStoragePrefix('still not cool'); // invoking with a param equals setting
		}
		
		catch(e) {
			
			expect(e.message).toBe('Illegal parameter: Local storage prefix is read-only');
		}		
	});
});