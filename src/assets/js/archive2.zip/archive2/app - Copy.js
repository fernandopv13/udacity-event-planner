'use strict';

/***********************************************************
* public module app
***********************************************************/

/** @description Creates a module for the app using the immediately invoked anonymous function pattern. In OO terms, basically a singleton of an anonymous class with no meaningful static members.
*
* @constructor
*
* @return {Object} Top-level singleton (module) providing a simple, encapsulated namespace, as well as module-level functionality, for the app.
*
* @author Ulrik H. Gade, January 2016
*
*/

var app = (function(self) {
	
	
	var _prefs = { // list of prefs, private so we can control access
		
		localStorageAllowed: false,	
	
		localStoragePrefix: 'dk.ulrikgade.udacity.srwebdev.meetup-app.'
	}
	
	
	self.prefs = { // accessors for preferences, using unified accessor pattern
		
		
		/** Gets or sets permission to store data locally */
		
		localStorageAllowed: function(bool_isAllowed) {
			
			if (typeof bool_isAllowed !== 'undefined') { // param present, so set
				
				if (typeof bool_isAllowed === 'boolean') {
				
					_prefs.localStorageAllowed = bool_isAllowed;
				}
				
				else {
					
					throw new TypeError('Wrong type: Expected Boolean');
				}
			}
			
			return _prefs.localStorageAllowed;
		},
		
		
		/** Gets prefix to be used in keys for local storage of app data (read-only) */
		
		localStoragePrefix: function() {
			
			if (arguments.length === 0) {
			
				return _prefs.localStoragePrefix;
			}
			
			else {
				
				throw new Error('Illegal parameter: Local storage prefix is read-only');
			}
		}
	}
		
	return self;
	
})(app || {});