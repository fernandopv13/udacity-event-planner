'use strict';

/***********************************************************
* public module app
***********************************************************/

/** @description Creates a module for the app using the immediately invoked anonymous function pattern. In OO terms, basically a singleton of an anonymous class with no meaningful static members.
*
* @constructor
*
* @return {Object} Top-level singleton (module) providing a simple, encapsulated namespace, as well as module-level functionality, for the app.
*
* @author Ulrik H. Gade, January 2016
*
*/

var app = (function(self) {
	
	var _registry = [];
	
	var _prefs = { // list of prefs, private so we can control access
		
		isLocalStorageAllowed: false,	
	
		localStoragePrefix: 'dk.ulrikgade.udacity.srwebdev.meetup-app.'
	}
	
	
	self.prefs = { // accessors for preferences, using unified accessor pattern
		
		
		/** Gets or sets permission to store data locally */
		
		isLocalStorageAllowed: function(bool_isAllowed) {
			
			if (typeof bool_isAllowed !== 'undefined') { // param present, so set
				
				if (typeof bool_isAllowed === 'boolean') {
				
					_prefs.isLocalStorageAllowed = bool_isAllowed;
				}
				
				else {
					
					throw new TypeError('Wrong type: Expected Boolean');
				}
			}
			
			return _prefs.isLocalStorageAllowed;
		},
		
		
		/** Gets prefix to be used in keys for local storage of app data (read-only) */
		
		localStoragePrefix: function() {
			
			if (arguments.length === 0) {
			
				return _prefs.localStoragePrefix;
			}
			
			else {
				
				throw new Error('Illegal parameter: Local storage prefix is read-only');
			}
		}
	}
		
	
	self.registry = { // parent functions for serializing/deserializing all the app's data in one fell swoop
		
		//ObjectRegistry needs named class reference, so cannot be used with anonymous module
		
		add: function(obj) { _registry.push(obj);},
		
		clear: function() {_registry = [];},
		
		writeObject: function() { /* write app data out to local storage */
			
			for (var i = 0, len = _registry.length; i < len; i++) {_registry[i].writeObject()}
		},
		
		readObject: function() {/* read in every object in list from local storage */},
		
		onDeserialized: function() {/* re-establish references after primary deserialization has completed */}
	}
	
	self.init = function() {
		
		self.registry.add(app.Account.registry);
	
		self.registry.add(app.Email.registry);
		
		self.registry.add(app.Event.registry);
		
		self.registry.add(app.Organization.registry);
		
		self.registry.add(app.Person.registry);
	};
	
	return self;
	
})(app || {});