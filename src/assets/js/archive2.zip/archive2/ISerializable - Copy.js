'use strict';

var app = app || {}; // create a simple namespace for the app


/***********************************************************
* public Interface ISerializable
***********************************************************/

/** @classdesc Represents an interface for classes that can be serialized for local or remote storage.
*
* @constructor
*
* @return {Error} An interface cannot be instantiated
*
* @author Ulrik H. Gade, January 2016
*
* @todo: Figure out how to get jsDoc to show (all) the method signature(s)
*/

app.ISerializable = function() {
	
	/*----------------------------------------------------------------------------------------
	* Method signatures
	*---------------------------------------------------------------------------------------*/
	
	/** Gets name of object's class.
	*
	* Inherited methods do not have access to private members, so can't provide default.
	*
	* @return {String} name Object's class name as string. Must evaluate to valide function as property of app.
	*/
	
	this.constructor.prototype.className = function() {
		
		throw new Error(app.ISerializable.prototype.className.errorMessage);
	}
	
	this.constructor.prototype.className.errorMessage = 'Method signature "className()" must be realized in derived classes';
	
	
	/** Gets object's unique id
	*
	* Inherited methods do not have access to private members, so can't provide default.
	*
	* @return {int} ID Object's unique ID (by class)
	*/
	
	this.constructor.prototype.id = function() {
		
		throw new Error(app.ISerializable.prototype.id.errorMessage);
	}
	
	this.constructor.prototype.id.errorMessage = 'Method signature "id()" must be realized in derived classes';
	
	
	/** Converts object to JSON object
	*
	* @return {Object} JSON object representation of person (used to override default behaviour of JSON.stringify())
	*/
	
	this.constructor.prototype.toJSON = function() {
		
		throw new Error(app.ISerializable.prototype.toJSON.errorMessage);
	}
	
	this.constructor.prototype.toJSON.errorMessage = 'Method signature "toJSON()" must be realized in derived classes';
	
	
	/** Re-establishes references to complex members after they have been deserialized */
	
	this.constructor.prototype.onDeserialized = function() {
		
		throw new Error(app.ISerializable.prototype.onDeserialized.errorMessage);
	}
	
	this.constructor.prototype.onDeserialized.errorMessage = 'Method signature "onDeserialized()" must be realized in derived classes';
		
	
	/*----------------------------------------------------------------------------------------
	* Block instantiation
	*---------------------------------------------------------------------------------------*/
		
	this.constructor.constructorErrorMessage = 'Interface ISerializable cannot be instantiated. Realize in derived classes.';
	
	throw new Error(this.constructor.constructorErrorMessage);
}



/*----------------------------------------------------------------------------------------
* Default methods (must be defined outside main function/class body)
*---------------------------------------------------------------------------------------*/


/** Automatically parses primitive private attributes in JSON object that have unified standard accessors, when instantiating class from JSON (i.e. called from within constructor).
*
* Re-referencing of more complex objects has to wait until this process has completed for all primary classes in the app, making the objects available in memory.
*
* Private attribute names must lead with a single underscore ('_'). Standard accessors have the same name as the attribute they set, except for removing any leading underscore. They can both set and get the value of the attribute, and manage basic validation and error handling. They must also be able to gracefully handle being passed a null.

* @param {Object} self Reference to the 'this' object in the calling class being instantiated

* @param {Object} json Representation in JSON format of the calling class being instantiated

* @param {String} class Name of the class being instantiated
*
* @param {Array} exclusions List of names of attributes to skip, e.g. because they cannot simply be set by calling an accessor
*
* @return true if succesfull, otherwise throws error
*
* @throws {ReferenceError} If JSON object does not have a valid ID
*
* @throws {TypeError} If JSON object is of the wrong class. (This may be redundant now that individual classes include the same check.)
*
* @todo Add handling of public, as well as private, attributes
*
* @todo Add unit test that tests this directly, rather than indirectly through its use by other classes
*/


/*
app.ISerializable.prototype.default_parseParams = function(obj_json, arr_exlusions) {
	
	var exclusions = arr_exlusions || []; exclusions.push('_className');  exclusions.push('_id');
	
	function isPrimitive(str) {return ['boolean','undefined','number','string','symbol'].indexOf(str) > -1}
	
	
	if (obj_json._className === this.className()) { // object has correct type
		
		if (parseInt(obj_json._id) === obj_json._id && obj_json._id > -1) { // object has valid ID
			
			for (var prop in obj_json) {
				
				if (exclusions.indexOf(prop) === -1) { // skip props in exclusions list
				
					// maybe call accessor on anything that has an underscore, and where accessor exists; might handle most complexes too
					
					if (obj_json[prop] === null || isPrimitive(typeof obj_json[prop])) {
					
						// call accessor (assumed have same name as property, except popping leading underscore)
						
						this[prop.slice(1)](obj_json[prop]); // primitive data type, call the property's accessor
					}
					
					// else: placeholder for complex data type (array or object), leave for re-referincing later
				}
				
				// else: in exclusions list, leave for custom logic to sort out
			}
		}
		
		else {
			
			throw new ReferenceError('Cannot re-instantiate object: ID not defined or not valid');
		}
	}
	
	else {
		
		throw new TypeError('Cannot re-instantiate object. Unexpected constructor: ' + obj_json._className);
	}
	
	return true;
}
*/

/** Writes object to local storage
*
* @return {Boolean} true if successful, otherwise throws error
*
* @throws {TypeError} If caller does not provide an accessor to a valid className, or if object contains a circular reference.
*
* @throws {RangeError} If object contains circular reference to itself.
*/

app.ISerializable.prototype.default_writeObject = function() {

	if (!window.localStorage) {throw new ReferenceError('localStorage not available');}
	
	if (!app.prefs.localStorageAllowed()) {throw new Error('Use of local storage not allowed by user');}
	
	if (![this.className()] || typeof app[this.className()] !== 'function') {throw new TypeError('Invalid class: ' + this.className());}
	
	if (typeof this.id() === 'undefined' || this.id() !== parseInt(this.id()) || this.id() < 0) {throw new RangeError('Invalid ID: ' + this.id());}
	
	
	try { // several things may fail here...
		
		localStorage.setItem(app.prefs.localStoragePrefix() + this.className() + '.' + this.id(), JSON.stringify(this));
	}
	
	catch(e) { // ...so, for now, just bubble up the native error
		
		throw e;
	}
	
	return true;
}


/** Reads object from local storage.
*
* Does most of the work of re-instantiation, in the style of the equivalent Java Serialize API method
*
* @return {Object} JSON representation of object if successful, otherwise null.
*/

app.ISerializable.prototype.default_readObject = function(arr_exclusions) {

	if (!window.localStorage) {throw new ReferenceError('localStorage not available');}
	
	if (!app.prefs.localStorageAllowed()) {throw new Error('Use of local storage not allowed by user');}
	
	
	// Read in JSON from local storage
	
	var obj_json = (function readJSON() {  // Inner function merely for stylistic purposes during coding
		
		try { // not sure exactly what failure here looks like ...
			
			return JSON.parse(localStorage.getItem(app.prefs.localStoragePrefix() + this.className() + '.' + this.id()));
		}
		
		catch(e) { // ...so, for now, just bubble up the native error
			
			throw e;
		}
		
	}.bind(this))();
	
	
	// Verify JSON
	
	(function verifyJSON() { // Inner function merely for stylistic purposes during coding
		
		// Check that read was succesful
		
		if (obj_json === null) { // localStorage.getItem() returns null if no object found
			
			throw new ReferenceError('Object not found in local storage');
		}
		
		
		// Verify that JSON object is instance of the correct class

		if (obj_json._className !== this.className()) {throw new TypeError('Wrong class "' + obj_json._className + '": Expected ' + this.className());}

		
		// Verify that JSON object has a valid id

		if (typeof obj_json._id === 'undefined') { // id does not exist
			
			throw new ReferenceError('Cannot re-instantiate object: ID not defined');
		}
			
		else if (parseInt(obj_json._id) !== obj_json._id) { // id is not an integer
				
			throw new TypeError('Cannot re-instantiate object: ID must be an integer');
		}
		
		else if (obj_json._id < 0) { // id is negative
			
			throw new RangeError('Cannot re-instantiate object: ID must be greater than or equal to zero');
		}
		
		else if (obj_json._id !== this.id()) { // id is different from that passed in by caller
			
			throw new ReferenceError('ID mismatch: ' + this.id() + ' does not equal ' + obj_json._id);
		}
		
	}.bind(this))();
	

	// Parse JSON properties into new object instance (assumes JSON has been verified)
	
	(function parseJSON(obj_json, arr_exclusions) { // Inner function merely for stylistic purposes during coding
	
		var exclusions = arr_exclusions || []; exclusions.push('_className');  exclusions.push('_id');
		
		function isPrimitive(str) {return ['boolean','undefined','number','string','symbol'].indexOf(str) > -1}
		
			for (var prop in obj_json) {
				
				if (exclusions.indexOf(prop) === -1) { // skip props in exclusions list
				
					// maybe call accessor on anything that has an underscore, and where accessor exists; might handle most complexes too
					
					if (obj_json[prop] === null || isPrimitive(typeof obj_json[prop])) {
					
						// call accessor (assumed have same name as property, except popping leading underscore)
						
						this[prop.slice(1)](obj_json[prop]); // primitive data type, call the property's accessor
					}
					
					// else: placeholder for complex data type (array or object), leave for re-referincing later
				}
				
				// else: in exclusions list, leave for custom logic to sort out
			}
		
		return true;
		
	}.bind(this))(obj_json, arr_exclusions);
	
	
	// Return JSON
	
	return obj_json; // caller may need to do custom post-processing of excluded properties
}


/** Removes object from local storage
*
* @return {undefined} Return is void.
*/

app.ISerializable.prototype.default_removeObject = function() {

	if (!window.localStorage) {throw new ReferenceError('localStorage not available');}
	
	if (!app.prefs.localStorageAllowed()) {throw new Error('Use of local storage not allowed by user');}
	
	
	try { // not sure what might fail here...
		
		localStorage.removeItem(app.prefs.localStoragePrefix() + this.className() + '.' + this.id());
	}
	
	catch(e) { // ...so, for now, just bubble up the native error
		
		throw e;
	}
}