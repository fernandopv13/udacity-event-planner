/* Custom error template */
/*
function MyError(message) {
	
	this.name = 'MyError';
	
	this.message = message || 'Default message';
	
	this.stack = (new Error()).stack;
}

MyError.prototype = Object.create(Error.prototype);

MyError.prototype.constructor = MyError;
*/

function ClassNotFoundError(message) {
	
	this.name = 'ClassNotFoundError';
	
	this.message = message || 'Class not found';
	
	this.stack = (new Error()).stack;
}

ClassNotFoundError.prototype = Object.create(Error.prototype);

ClassNotFoundError.prototype.constructor = ClassNotFoundError;



function IllegalAccessError(message) {
	
	this.name = 'IllegalAccessError';
	
	this.message = message || 'Illegal access';
	
	this.stack = (new Error()).stack;
}

IllegalAccessError.prototype = Object.create(Error.prototype);

IllegalAccessError.prototype.constructor = IllegalAccessError;



function IllegalArgumentError(message) {
	
	this.name = 'IllegalArgumentError';
	
	this.message = message || 'Illegal argument';
	
	this.stack = (new Error()).stack;
}


IllegalArgumentError.prototype = Object.create(Error.prototype);

IllegalArgumentError.prototype.constructor = IllegalArgumentError;



function InstantiationError(message) {
	
	this.name = 'InstantiationError';
	
	this.message = message || 'Instantiation not permitted';
	
	this.stack = (new Error()).stack;
}

InstantiationError.prototype = Object.create(Error.prototype);

InstantiationError.prototype.constructor = InstantiationError;



