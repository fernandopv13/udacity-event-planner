'use strict'; // Not in functions to make it easier to remove by build process

var app = app || {}; // create a simple namespace for the app


/**********************************************************************************************
* public class Event implements ISerializable
**********************************************************************************************/

/** @classdesc Holds information about an event.
*
* @constructor
*
* @implements ISerializable
*
* @param {String} name The name of the event
*
* @param {String} type The type of event (e.g. birthday, bachelor's party, religious holiday etc.)
*
* @param {Date} start The date and time when the event starts
*
* @param {Date} end The date and time when the event ends
*
* @param {int} capacity The maximum number of guests at the event
*
* @param {String} location The location where the event is held
*
* @param {String} description A brief description of the event
*
* @param {IHost} host The host of the event
*
* @return {Event} An Event instance
*
* @author Ulrik H. Gade, January 2016
*/

app.Event = function(str_name, str_type, date_start, date_end, str_location, str_description, ihost_host, int_capacity) {
	
	
	/*----------------------------------------------------------------------------------------
	* Private instance fields (encapsulated data members)
	*---------------------------------------------------------------------------------------*/
	
	// Any strong typing is enforced by the accessor methods.
	
	var _id, // (int) Unique event ID obtained from Event object registry
	
	_name,
	
	_type,
	
	_start,
	
	_end,
	
	_capacity,
	
	_guests = [], // (Person array) A collection of guests invited to, or participating in, the event
	
	_location,
	
	_description,
	
	_host;
		

		
	/*----------------------------------------------------------------------------------------
	* Accessors for private instance fields
	*---------------------------------------------------------------------------------------*/
		
	/** Gets unique event ID. ID can only be set from within the object itself.
	*
	* (Method realization required by IIdentifiable.)
	*
	* @return {int} An integer, if called with no parameters
	*	
	* @throws {Error} If called with one or more parameters (so mistake is easily detectable)
	*/
	
	this.id = function () {
		
		if(arguments.length === 0) { return _id;}
		
		else {
			
			throw new Error('Illegal parameter: id is read-only');
		}
	};
	
	
	/** Gets or sets name
	*
	* @param {String} name The name of the event (optional, supply if setting)
	*
	* @return {String} The name of the event
	*/
	
	this.name = function (str_name) {
		
		if (arguments.length !== 0) {
			
			_name = str_name;
		}
		
		return _name;
	}
	
	
	/** Gets or sets event type
	*
	* @param {String} type The type of event (e.g. birthday, bachelor's party, religious holiday etc.) (optional, supply if setting)
	*
	* @return {String} The type of event (e.g. birthday, bachelor's party, religious holiday etc.)
	*/
	
	this.type = function (str_type) {
		
		if (arguments.length !== 0) {
			
			_type = str_type;
		}
		
		return _type;
	}
	

	/** Gets or sets the start date
	*
	* @description Takes a single parameter when setting: either a Date object or a valid date string.
	*
	* @param {Date} start The date and time when the event starts (Date representation)
	*
	* @param {String} start The date and time when the event starts (String representation)
	*
	* @return {Date} The date and time when the event starts
	*/
	
	this.start = function(date_start) {
		
		if (arguments.length !== 0) {
			
			if (date_start !== null) {
				
				if (date_start.constructor === Date) { // date as Date; default form
					
					_start = date_start;
				}
				
				else if (!isNaN(Date.parse(date_start))) { // date as string; mostly used to parse in from JSON
					
					_start = new Date(date_start);
				}
				
				else {
					
					throw new TypeError('Start must be Date');
				}
			} // silently ignore null
		}
		
		return _start;
	};


	/** Gets or sets the end date
	*
	* @description Takes a single parameter when setting: either a Date object or a valid date string.
	*
	* @param {Date} end The date and time when the event ends (Date representation)
	*
	* @param {String} start The date and time when the event starts (String representation)
	*
	* @return {Date} The date and time when the event ends
	*/
	
	this.end = function(date_end) {
		
		if (arguments.length !== 0) {
			
			if (date_end !== null) {
				
				if (date_end.constructor === Date) { // date as Date; default form
					
					_end = date_end;
				}
				
				else if (!isNaN(Date.parse(date_end))) { // date as string; mostly used to parse in from JSON
					
					_end = new Date(date_end);
				}
				
				else {
					
					throw new TypeError('End must be Date');
				}
			} // silently ignore null
		}
		
		return _end;
	};


	/** Gets or sets capacity
	*
	* @param {int} capacity The capacity of the event (optional, supply if setting)
	*
	* @return {int} The capacity of the event
	*
	* @throws {RangeError} If capacity is set lower than zero
	*/
	
	this.capacity = function (int_capacity) {
		
		if (arguments.length !== 0) {
			
			if (int_capacity !== null) { // i.e. undefined when serialized, ignore
			
				if (parseInt(int_capacity) === int_capacity) { // integer required
				
					if (parseInt(int_capacity) >= 0) { // must not be negative
				
						_capacity = parseInt(int_capacity);
					}
					
					else {
						
						throw new RangeError('Capacity cannot be negative');
					}
				}
				
				else {
					
					throw new TypeError('Capacity must be an integer');
				}
			}
		}
		
		return _capacity;
	}
	
	
	/** Gets copy of the guest list for the event. Guest list cannot be manipulated directly: use add() or remove() methods.
	*
	* return {Array} A Person array
	*
	*@throws {Error} If called with one or more parameters (so mistake is easily detectable)
	*/
 	
	this.guestList = function() {
	
		if (arguments.length === 0) {
			
			return _guests;
		}
			
		else {
				
				throw new Error('Illegal parameter: id is read-only');
		}
	}
	

	/** Adds a person to the event's guest list */

	this.addGuest = function (obj_guest) {
		
		if (obj_guest.constructor === app.Person) { // only a Person can be a guest
			
			if(_guests.length < _capacity - 1) { // we cannot add guests beyond capacity
			
				_guests.push(obj_guest);
			}
			
			else {
				
				throw new RangeError('Cannot add guests beyond capacity');
			}
		}
		
		else {
			
			throw new TypeError('Guest must be Person');
		}
		
		return obj_guest;
	};


	/** Checks if a person is on the event's guest list
	*
	* @return {Boolean} True if the person is on the guest list, else false
	*/

	this.isGuest = function (obj_person) {
		
		var ret = false;
		
		if (obj_person.constructor === app.Person) {
			
			_guests.forEach(function(guest) {
				
				if (guest.id() === obj_person.id()) {ret = true;} // can't 'break' out of forEach
			});
		}
		
		else {
			
			throw new TypeError('Guest must be Person');
		}
		
		return ret;
	};


	/** Removes a person from the event's guest list
	*
	* @return {Array} An array with the person that was removed, an empty array if the person was not found on the guest list
	*/

	this.removeGuest = function (obj_person) {
		
		var ret;
		
		if (obj_person.constructor === app.Person) {
			
			for (var i = 0, len = _guests.length; i < len; i++) {
			
				if (_guests[i].id() === obj_person.id()) {
					
					ret = _guests.splice(i, 1);
					
					break;
				}
			}
		}
		
		else {
			
			throw new TypeError('Guest must be Person');
		}
		
		return ret;
	};


	/** Gets or sets location
	*
	* @param {String} location The location of the event (optional, supply if setting)
	*
	* @return {String} The location of the event
	*/
	
	this.location = function (str_location) {
		
		if (arguments.length !== 0) {
			
			_location = str_location;
		}
		
		return _location;
	}
	
	
	/** Gets or sets description
	*
	* @param {String} description A short description of the event (optional, supply if setting)
	*
	* @return {String} A short description of the event
	*/
	
	this.description = function (str_description) {
		
		if (arguments.length !== 0) {
			
			_description = str_description;
		}
		
		return _description;
	}
	
	
	/** Gets or sets the host
	*
	* @param {IHost} host The person or organization hosting the event
	*
	* @return {IHost} The person or organization hosting the event
	*/
	
	this.host = function(Ihost_host) {
		
		if (arguments.length !== 0) {
			
			if (typeof Ihost_host.hostName === 'function') { // revisit type checking of IHost after deciding whether to refactor it to abstract class
				
				_host = Ihost_host;
			}
			
			else {
				
				throw new TypeError('Host must implement IHost')
			}
		}
		
		return _host;
	};
	
	
	
	/*----------------------------------------------------------------------------------------
	* Private instance methods (may depend on accessors, so declare after them)
	*---------------------------------------------------------------------------------------*/
	
	// None so far
		
	
	/*----------------------------------------------------------------------------------------
	* Public instance methods (beyond accessors)
	*---------------------------------------------------------------------------------------*/
	
	/** Re-establishes references to complex members after they have been deserialized
	*
	* (Method realization required by ISerializable.)
	*/

	this.onDeserialized = function() { // Replace IDs with references to objects of that ID
		
		for (var i = 0, len = _guests.length; i < len; i++) { // Guest list
			
			_guests[i] = app.Person.registry.getObjectById(_guests[i]._id);
		}
		
		/*
		_guests.forEach(function(guest) { // this generated random errors, so going old school
		
			console.log(guest);
			
			_guests[guest] = app.Person.registry.getObjectById(guest);
		});
		*/
		
		
		if (_host !== null) {//Host
		
			_host = app[_host._constructor_].registry.getObjectById(_host._id);
			
			//var id = _host.split(',')[0], clss = _host.split(',')[1];
			
			//_host = app[clss === 'Person' ? 'Person' : 'Organization'].registry.getObjectById(id);
		}
		
		return true;
	}

	
	/** Converts event to JSON object
	*
	* (Method realization required by ISerializable.)
	*
	* @return {Object} JSON object representation of event (used to override default behaviour of JSON.stringify())
	*/
		
	this.toJSON = function () { // we need private access so no prototype inheritance here
		
		return {
			
			_constructor_: 'Event',
			
			_id: _id,
			
			_start: _start ? _start : null,
			
			_end: _end ? _end : null,
			
			_name: _name ? _name : null,
			
			_type: _type ? _type : null,
			
			_location: _location ? _location : null,
			
			_description: _description ? _description: null, // may need to remove line breaks
			
			_host: _host ? {_constructor_: _host.constructor === app.Person ? 'Person' : 'Organization', _id: _host.id()} : _host, // if host is undefined, pass in undefined
			
			_capacity: _name >= 0 ? _capacity : null,
			
			_guests: (function() { // store array of guest reference objects
				
				var ret = [];
				
				_guests.forEach(function(guest) {
					
					ret.push({_constructor_: 'Person', _id: guest.id()});
				});
				
				return ret;
			})()
		};
	};
	
		
	/*----------------------------------------------------------------------------------------
	* Parameter parsing (constructor 'polymorphism')
	*---------------------------------------------------------------------------------------*/
		
	if (arguments[0] && arguments[0]._constructor_) { // Deserialize from JSON
		
		// We have a first param that is object retrieved from JSON storage, so re-instantiate.
		// This approach is neccessary because we want to keep the id private.
		 
		
		// Verify that JSON object is of the correct type
		
		if (arguments[0]._constructor_ !== 'Event') {throw new TypeError('Wrong constructor "' + arguments[0]._constructor_ + '". Expected Event');}
		
	
		// Re-set original ID
		
		_id = arguments[0]._id;
		 
		
		// Call the default parser of primitives mixed in from ISerializable
		
		this.parseParams(arguments[0], 'Event', ['_guests', '_host']);
		
		 
		// Custom handle a couple of objects
		
		_guests = arguments[0]._guests ? arguments[0]._guests : null;
								
		_host = arguments[0]._host ? arguments[0]._host : null;
	}

	else { // Normal instantiation
		
		// Set unique ID
		
		_id = this.constructor.registry.getNextId();
		
		
		// Call accessors for any supplied params (accessors provide simple validation and error handling)
		
		if (str_name) {this.name(str_name)}
				
		if (str_type) {this.type(str_type)}
		
		if (date_start) {this.start(date_start)}
		
		if (date_end) {this.end(date_end)}
		
		if (int_capacity >= 0) {this.capacity(int_capacity)}
		
		if (str_location) {this.location(str_location)}
		
		if (str_description) {this.description()}
		
		if (ihost_host) {this.host(ihost_host)}
	}

	this.constructor.registry.add(this); // Will only happend if param passing passes w/o error
};


/*----------------------------------------------------------------------------------------
* Public class (static) members
*---------------------------------------------------------------------------------------*/

/** Provides non-mutable, unique organization IDs */

app.Event.registry = new app.ObjectRegistry(app.Event, 'Event');


/*----------------------------------------------------------------------------------------
Mix in default methods from implemented interfaces, unless overridden by class or ancestor
*---------------------------------------------------------------------------------------*/

void app.InterfaceHelper.mixInto(app.ISerializable, app.Event);