'use strict';

var app = app || {}; // create a simple namespace for the app


/***********************************************************
* public class Person implements IHost ISerializable
***********************************************************/

/** @classdesc Describes a person who may host and/or participate in an event.
*
* @constructor
*
* @implements IHost, ISerializable
*
* @param {String} name The full name of the person
*
* @param {Organization} employer The person's employer
*
* @param {String} jobTitle The person's job title
*
* @param {Email} email The person's email
*
* @return {Person} A Person instance
*
* @author Ulrik H. Gade, December 2015/January 2016
*
* @throws Same errors as email and employer accessors if passing in invalid data.
*
* @todo Add birthday to data stored about a Person
*/

app.Person = function(str_name, obj_employer, str_jobTitle, obj_email) {

	/*----------------------------------------------------------------------------------------
	* Private instance fields (encapsulated data members)
	*---------------------------------------------------------------------------------------*/
	
	// Any strong typing is enforced by the setter methods.
		
	var _id, // (int) Unique person ID obtaining from Person object registry
	
	_name,
	
	_employer,
	
	_jobTitle,
	
	_email;
	


	/*----------------------------------------------------------------------------------------
	* Accessors for private instance fields
	*---------------------------------------------------------------------------------------*/

	/** Gets unique person ID. ID can only be set from within the object itself.
	*
	* (Method realization required by IIdentifiable.)
	*
	* @return {int} An integer, if called with no parameters
	*	
	* @throws {Error} If called with one or more parameters (so mistake is easily detectable)
	*/
	
	this.id = function () {
		
		if(arguments.length === 0) { return _id;}
		
		else {
			
			throw new Error('Illegal parameter: id is read-only');
		}
	};
	
	
	/** Gets or sets name
	*
	* @param {String} name The person's full name (optional, supply if setting)
	*
	* @return {String} The person's full name
	*/
	
	this.name = function (str_name) {
		
		if (arguments.length !== 0) {
			
			_name = str_name;
		}
		
		return _name;
	}
	
		
	/** Gets or sets email
	*
	* @param {Email} email The person's current email (optional, supply if setting)
	*
	* @return {Email} The person's current email
	*
	* @throws {TypeError} If attempting to set email not of class Email
	*/
	
	this.email = function (obj_email) {
		
		if (arguments.length !== 0) {
			
			if (obj_email.constructor === app.Email) {
				
				_email = obj_email;
			}
			
			else {
				
				throw new TypeError('Wrong type: Email must be an instance of the Email class')
			}
		}
		
		return _email;
	}
	
	
	/** Gets or sets employer
	*
	* @param {Organization} employer The person's current employer (optional, supply if setting)
	*
	* @return {Organization} The person's current employer
	*
	* @throws {TypeError} If attempting to set employer not of class Employer
	*/
	
	this.employer = function (obj_employer) {
		
		if (arguments.length !== 0) {
			
			if (obj_employer.constructor === app.Organization) {
				
				_employer = obj_employer;
			}
			
			else {
				
				throw new TypeError('Employer must be Organization')
			}
		}
		
		return _employer;
	}
	
	
	/** Gets or sets host name (implementing IHOST)
	*
	* @param {String} name The person's full name (optional, supply if setting)
	*
	* @return {String} The person's full name
	*/
	
	this.hostName = function (str_hostName) {
		
		if (arguments.length !== 0) {
			
			_name = str_hostName;
		}
		
		return _name;
	}
	
	
	/** Gets or sets job title
	*
	* @param {String} jobTitle The person's job title (optional, supply if setting)
	*
	* @return {String} The person's job title
	*/
	
	this.jobTitle = function (str_jobTitle) {
		
		if (arguments.length !== 0) {
			
			_jobTitle = str_jobTitle;
		}
		
		return _jobTitle;
	}

	
	/*----------------------------------------------------------------------------------------
	* Private instance methods (may depend on accessors, so declare after them)
	*---------------------------------------------------------------------------------------*/
	
	// None so far
	
	/*----------------------------------------------------------------------------------------
	* Public instance methods (beyond simple accessors)
	*---------------------------------------------------------------------------------------*/

	
	/** Re-establishes references to complex members after they have been deserialized
	*
	* (Method realization required by ISerializable.)
	*/
	
	this.onDeserialized = function() { // Replace IDs with references to objects of that ID
		
		if (_email !== null) {_email = app.Email.registry.getObjectById(_email)}
		
		if (_employer !== null) {_employer = app.Organization.registry.getObjectById(_employer)}
	}
	
	
	/** Converts person to JSON object
	*
	* (Method realization required by ISerializable.)
	*
	* @return {Object} JSON object representation of person (used to override default behaviour of JSON.stringify())
	*/
	
	this.toJSON = function () { // we need private access so no prototype inheritance here
		
		return {
			
			_constructor_: 'Person',
			
			_id: _id,
			
			_name: _name ? _name : null,
			
			_email: _email ? _email.id(): null,
			
			_employer: _employer ? _employer.id(): null,
			
			_jobTitle: _jobTitle ? _jobTitle : null
		};
	};
	
	
	
	/*----------------------------------------------------------------------------------------
	* Parameter parsing (constructor 'polymorphism')
	*---------------------------------------------------------------------------------------*/
	
	if (arguments[0] && arguments[0]._constructor_) { // Deserialize from JSON
		
		// We have a first param that is object retrieved from JSON storage, so re-instantiate.
		// This approach is neccessary because we want to keep the id private.
		 
		
		// Verify that JSON object is of the correct type
		
		if (arguments[0]._constructor_ !== 'Person') {throw new TypeError('Wrong constructor "' + arguments[0]._constructor_ + '". Expected Person');}
		
	
		// Re-set original ID
		
		_id = arguments[0]._id;
		 
		
		// Call the default parser of primitives mixed in from ISerializable
		
		this.parseParams(arguments[0], 'Person', ['_email', '_employer']);
		
		 
		// Custom handle a couple of objects
		
		_email = arguments[0].email ? arguments[0]._email : null;
		
		_employer = arguments[0]._employer ? arguments[0]._employer : null;
	}
	
	else { // Normal instantiation
	
		// Set unique ID
		
		_id = this.constructor.registry.getNextId();
		
		
		// Call accessors for any supplied params (accessors provide simple validation and error handling)
		
		if (str_name) {this.name(str_name)}
				
		if (obj_employer) {this.employer(obj_employer)}
		
		if (str_jobTitle) {this.jobTitle(str_jobTitle)}
		
		if (obj_email) {this.email(obj_email)}
	}
	
	this.constructor.registry.add(this); // Will only happend if param passing passes w/o error
};

/*----------------------------------------------------------------------------------------
* Public class (static) members
*---------------------------------------------------------------------------------------*/

/** Provides registry and unique object ID services to this class  */

app.Person.registry = new app.ObjectRegistry(app.Person, 'Person');



/*----------------------------------------------------------------------------------------
Mix in default methods from implemented interfaces, unless overridden by class or ancestor
*---------------------------------------------------------------------------------------*/

void app.InterfaceHelper.mixInto(app.IHost, app.Person);

void app.InterfaceHelper.mixInto(app.ISerializable, app.Person);