'use strict';

var app = app || {}; // create a simple namespace for the app


/***********************************************************
* public class ObjectRegistry
***********************************************************/

/** @classdesc Keeps track of the objects created of a class, to help avoid duplication when serializing objects for local or remote storage. Can only hold objects of the same class.
*
* @constructor
*
* @param {Function} classReference The type of object tracked by the registry (by function reference)
*
* @param {String} className The type of object tracked by the registry (by simple class name)
*
* @return {ObjectRegistry} A utility for other classes, providing unique, zero indexed object IDs while the app is runnning
*
* @author Ulrik H. Gade, January 2016
*
* @todo Streamline naming of methods dealing with JSON to reflect normal JS usage
*/

app.ObjectRegistry = function(func_classReference, str_className) {
	
	/*----------------------------------------------------------------------------------------
	* Private instance fields (encapsulated data members)
	*---------------------------------------------------------------------------------------*/
	
	// Any strong typing is enforced by the setter methods.
		
	var _objectList = {}, // (Object) A collection of the objects the registry keeps track of
	
	_objectCount = 0, // (int) The number of objects add to the collection (does not decrement when removing items)
	
	_classReference, // (Function) The type of object tracked by the registry (by reference).
	
	_className; // (String) The type of object tracked by the registry (by name).
	
		
	/*----------------------------------------------------------------------------------------
	* Accessors for private instance fields
	*---------------------------------------------------------------------------------------*/
	
	/** Gets next unique object ID
	*
	* @return {int} The next free object ID. IDs are incremented at each successful call to the add() method. They may evolve to bear no relation to the actual number of objects existing at any one time.
	*/
	
	this.getNextId = function() {return _objectCount;};
	

	/** Adds an object to the registry
	*
	* @param {Object} obj An instance of the class the registry was created to hold
	*
	* @return {Boolean} true if object is added successfully, otherwise undefined
	*
	* @throws {RangeError}  If object does not provide an id() method that returns a non-negative integer
	*
	* @throws {TypeError} If object is of the wrong class for this registry
	*/

	this.add = function(obj) {
		
		if (obj.constructor === _classReference) {
			
			if (obj.id && typeof obj.id === 'function' && obj.id() === parseInt(obj.id()) && obj.id() > -1) {
		
				//console.log('registry add ' + (_classReference == app.Event ? 'Event ': '') + obj.id());
				
				//try {console.log(obj.guestList())} catch(e) {}
		
				var exists = false, len = _objectList.length;
				
				for (var prop in _objectList) {
				
					if (_objectList[prop].id() === obj.id()) {
						
						exists = true;
						
						break;
					}
				}
				
				if (!exists) {
					
					_objectList[_objectCount] = obj;
					
					_objectCount++;
				}
			}
			
			else {
				
				throw new RangeError('Object must support a id() method that returns a non-negative integer');
			}
		}
		
		else {
			
			throw new TypeError('Wrong type for this registry');
		}
		
		return true; //mostly needed for testing purposes
	}
	
	
	/** Gets a reference to an object in the registry by its ID
	*
	* @return {Object} A reference to the object with the ID, or undefined if not in registry
	*/
	
	this.getObjectById = function(id) {
	
		return _objectList[id];
	}
	
	
	/** Gets a reference to an object in the registry by the value of an attribute
	*
	* @param {String} name The attribute name by which to get the object. Expected to be accessor method if attribute is private.
	*
	* @param {Object} val The value of the attribute by which to get the object. Can by any legal JS type.
	*
	* @return {Object} A reference to the object with the ID, or null if not in registry.
	*/
	
	this.getObjectByAttribute = function(str_name, obj_val) {
	
		var obj, val;
		
		for (var id in _objectList) {
			
			obj = _objectList[id];
			
			for (var prop in obj) {
				
				if (prop === str_name) {
					
					val = typeof obj[prop] === 'function' ? obj[prop]() : obj[prop];
					
					if (val === obj_val) {
						
						return obj;
					}
				}
			}
		}
		
		return null;
	}
	

	/** Removes an object from the registry
	*
	* @return {Object} An The object that was removed, or null if the object was not found in the registry
	*/
	
	this.remove = function(obj) {
		
		if (obj.constructor === _classReference) {
		
			if (obj.id && typeof obj.id === 'function' && obj.id() === parseInt(obj.id()) && obj.id() > -1) {
				
				var id = obj.id();
				
				if (typeof _objectList[id] !== 'undefined') {
					
					var ret = _objectList[id];
					
					delete _objectList[id];
					
					return ret;
				}
			}
			
			else {
				
				throw new RangeError('Object must support a id() method that returns a non-negative integer');
			}
		}
		
		else {
			
			throw new TypeError('Wrong type for this registry');
		}
		
		return null;
	}
	
	
	/** Gets list of objects in the registry */
	
	this.getObjectList = function() {return _objectList};/** Get type of object required (by function reference) */
	
	
	/** Gets the type (class) of objects required by the registry (by function reference) */
	
	this.type = function() {return _classReference;};
	
	
		
	/*----------------------------------------------------------------------------------------
	* Public instance methods (beyond accessors)
	*---------------------------------------------------------------------------------------*/
	
	/** Desirializes JSON object list into instances of the class held by the registry
	*
	* @return {Object} A list of the objects re-created in the registry, or false if not succesfull
	*/
		
	this.processJSON = function (obj_json) { // we need private access so no prototype inheritance here
	
		//console.log(obj_json);
		
		var obj;
		
		for (var prop in obj_json) {
			
			obj = obj_json[prop];
			
			if (obj._constructor_) { // the constructor property is defined
				
				if (app[obj._constructor_] === _classReference) { // the object is the correct type (by function reference)
					
					this.add(new app[obj._constructor_](obj)); // Call the class' constructor, passing the JSON object
					
					_objectCount = Math.max(_objectCount, obj._id); // make sure the counter is no less than the highest id
				}
				
				else {
					
					throw new TypeError('Wrong type: Class must be ' + _className);
				}
			}
		}
		
		_objectCount++; // make sure the counter is at least one step ahead (the actual number is unimportant)
		
		return true;
	}
	
	
	/** Re-establishes references to complex members after they have been deserialized.
	*
	* (Method realization required by ISerializable.)
	*/
	
	this.onDeserialized = function() {
		
		for (var prop in _objectList) {
			
			_objectList[prop].onDeserialized();
		}
	}
	
	
	/** Converts registry contents to JSON objects
	*
	* (Method realization required by ISerializable.)
	*
	* @return {Object} JSON object representation of registry and its object list (used to override default behaviour of JSON.stringify())
	*/
	
	this.toJSON = function () { // we need private access so no prototype inheritance here
		
		// For now, all we need is to return the object list as JSON.
		// There's no need to serialize the registry itself; it can easily
		// be recreated from scratch when desiralizing the actual objects
		// (just make sure to set the object counter to above the largest id)
		
		var ret = {}; //JSON.stringify implicitly calls onJSON(); it expects a valid JSON object
		
		for (var prop in _objectList) {
			
			ret[prop] = _objectList[prop].toJSON();
		}
		
		return ret;
	};
	
	
	/** Parses valid JSON string into class instances
	*
	* @return {String} String representation in JSON format of objects in registry
	*/
	
	/*this.parse = function (str_json) { // we need private access so no prototype inheritance here
		
		var arr_obj;
		
		try {
			
			arr_obj = JSON.parse(str_json);
		}
		
		catch(e) {
			
			throw new Error(e.message);
		}
		
		for (var i = 0; i < arr_obj.length; i++) {
			
			//console.log('registry parse()');
			
			this.add(new app[arr_obj[i]._constructor_](arr_obj[i]));
		}
	};*/

	
	/*----------------------------------------------------------------------------------------
	* * Parameter parsing (constructor 'polymorphism')
	*---------------------------------------------------------------------------------------*/

	if (typeof func_classReference === 'function') {
		 
		 _classReference = func_classReference;
		 
		 _className = str_className;
	}
	
	else {
		
		throw new TypeError('Type must be a function reference');
	}
}