'use strict'; // Not in functions to make it easier to remove by build process

/******************************************************************************
* public class Account implements ISerializable
******************************************************************************/

var app = app || {};


/** @classdesc Holds information about a account.
*
* @constructor
*
* @implements ISerializable
*
* @param {Email} email the email identifying the account
*
* @param {String} password A secure password for the account
*
* @return {Account} An account instance
*
* @throws Same errors as email and password accessors if passing in invalid data.
*
* @author Ulrik H. Gade, January 2016
*
*/

app.Account = function(Email_email, str_password) {


	/*----------------------------------------------------------------------------------------
	* Private instance fields (encapsulated data members)
	*---------------------------------------------------------------------------------------*/
	
	var	_className = 'Account', // (String) Name of this class
	
	_id,  // (int) Unique account ID obtained from Account object registry

	_email,
	
	_password;
	
	
	/*----------------------------------------------------------------------------------------
	* Accessors for private instance fields
	*---------------------------------------------------------------------------------------*/

	/** Gets name of object's class. Class name is read-only.
	*
	* (Method realization required by ISerializable.)
	*
	* @return {String} name The name of the object's class
	*	
	* @throws {Error} If called with one or more parameters (so mistake is easily detectable)
	*/
	
	this.className = function () {
		
		if(arguments.length === 0) { return _className;}
		
		else {
			
			throw new Error('Illegal parameter: className is read-only');
		}
	};
	
	
	/** Gets unique account ID. ID can only be set from within the object itself.
	*
	* (Method realization required by ISerializable)
	*
	* @return {int} An integer, if called with no parameters
	*	
	* @throws {Error} If called with one or more parameters (so mistake is easily detectable)
	*/
	
	this.id = function () {
		
		if(arguments.length === 0) { return _id;}
		
		else {
			
			throw new Error('Illegal parameter: id is read-only');
		}
	};
	
	
	/** Gets or sets email
	*
	* @param {Email} email The email for the account. (optional, supply if setting)
	*
	* @return {Email} The email for the account.
	*
	* @throws {TypeError} If attempting to set email not of class Email
	*/
	
	this.email = function (obj_email) {
		
		if (arguments.length !== 0) {
			
			if (obj_email.constructor === app.Email) {
				
				_email = obj_email;
			}
			
			else {
				
				throw new TypeError('Wrong type: Email must be an instance of the Email class')
			}
		}
		
		return _email;
	}
	
	
	/** Gets or sets password
	*
	* @param {String} password The account's password
	*
	* @return {String} The account's password.
	*
	* @throws {Error} If attempting to set insecure password
	*/
	
	this.password = function (str_password) {
		
		if (arguments.length !== 0) {
			
			if (!/^(.{0,7}|[^0-9]*|[^A-Z]*|[^a-z]*|[a-zA-Z0-9]*)$/.test(str_password)) {
				
				_password = str_password;
			}
			
			else {
				
				throw new Error('Invalid password: Passwords must be at least min. 8 chars long and have at least one each of uppercase, lowercase and non-alpha character');
			}
		}
		
		return _password;
	}
	
	
	/*----------------------------------------------------------------------------------------
	* Private instance methods (may depend on accessors, so declare after them)
	*---------------------------------------------------------------------------------------*/
	
	// None so far
		
	/*----------------------------------------------------------------------------------------
	* Public instance methods (beyond accessors)
	*---------------------------------------------------------------------------------------*/
	
	/** Re-establishes references to complex members after they have been deserialized.
	*
	* (Method realization required by ISerializable.)
	*/
	
	this.onDeserialized = function() { // Replace IDs with references to objects of that ID
		
		if (_email !== null) {_email = app.Account.registry.getObjectById(_email)}
	}
	
	
	/** Converts person to JSON object
	*
	* (Method realization required by ISerializable.)
	*
	* @return {Object} JSON object representation of person (used to override default behaviour of JSON.stringify())
	*/
	
	this.toJSON = function() { // we need private access so no prototype inheritance here
		
		return {
			
			_className: 'Account',
			
			_id: _id,
			
			_email: _email ? _email.id(): null,
			
			_password: _password ? _password : null
		};
	};
	
	
	
	/*----------------------------------------------------------------------------------------
	* Parameter parsing (constructor 'polymorphism')
	*---------------------------------------------------------------------------------------*/
	
	if (arguments[0] && arguments[0]._className) { // Deserialize from JSON
		
		// We have a first param that is object retrieved from JSON storage, so re-instantiate
		// This approach is neccessary to prevent other objects from changing the ID of the object in the registry
		
		
		// Verify that JSON object is of the correct type
		
		if (arguments[0]._className !== 'Account') {throw new TypeError('Wrong constructor "' + arguments[0]._className + '". Expected Account');}
		
	
		// Re-set original ID
		
		_id = arguments[0]._id;
		 
		
		// Call the default parser of primitives mixed in from ISerializable
		
		this.parseParams(arguments[0], 'Account', ['_email']);
		
		
		// Custom handle _email attribute
		
		_email = arguments[0]._email ? arguments[0]._email : null;
	}

	else { // Normal instantiation
			
		// Set unique ID
		
		_id = this.constructor.registry.getNextId();
		
		
		// Call accessors for any supplied params (accessors provide simple validation and error handling)
		
		if (Email_email) {this.email(Email_email);}
		
		if (str_password) {this.password(str_password);}
	}

	
	//Add to registry
	
	this.constructor.registry.add(this); // Will only happend if param passing passes w/o error
};


/*----------------------------------------------------------------------------------------
* Public class (static) members
*---------------------------------------------------------------------------------------*/

/** Provides registry and unique object ID services to this class  */

app.Account.registry = new app.ObjectRegistry(app.Account, 'Account');


/*----------------------------------------------------------------------------------------
Mix in default methods from implemented interfaces, unless overridden by class or ancestor
*---------------------------------------------------------------------------------------*/

void app.InterfaceHelper.mixInto(app.ISerializable, app.Account);