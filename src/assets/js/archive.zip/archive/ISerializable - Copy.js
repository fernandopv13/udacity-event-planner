'use strict';

var app = app || {}; // create a simple namespace for the app


/***********************************************************
* public Interface ISerializable
***********************************************************/

/** @classdesc Represents an interface for classes that can be serialized for local or remote storage.
*
* @constructor
*
* @return {Error} An interface cannot be instantiated
*
* @author Ulrik H. Gade, January 2016
*
* @todo: Figure out how to get jsDoc to show (all) the method signature(s)
*/

app.ISerializable = function() {
	
	/*----------------------------------------------------------------------------------------
	* Method signatures
	*---------------------------------------------------------------------------------------*/
	
	/** Gets name of object's class
	*
	* @return {String} name Object's class name as string. Must evaluate to valide function as property of app.
	*/
	
	this.constructor.prototype.className = function() {
		
		throw new Error(app.ISerializable.prototype.className.errorMessage);
	}
	
	this.constructor.prototype.className.errorMessage = 'Method signature "className()" must be realized in derived classes';
	
	
	/** Converts object to JSON object
	*
	* @return {Object} JSON object representation of person (used to override default behaviour of JSON.stringify())
	*/
	
	this.constructor.prototype.toJSON = function() {
		
		throw new Error(app.ISerializable.prototype.toJSON.errorMessage);
	}
	
	this.constructor.prototype.toJSON.errorMessage = 'Method signature "toJSON()" must be realized in derived classes';
	
	
	/** Re-establishes references to complex members after they have been deserialized */
	
	this.constructor.prototype.onDeserialized = function() {
		
		throw new Error(app.ISerializable.prototype.onDeserialized.errorMessage);
	}
	
	this.constructor.prototype.onDeserialized.errorMessage = 'Method signature "onDeserialized()" must be realized in derived classes';
	
	
	/** Writes object to local storage */
	
	
	/** Reads object from local storage */
	
	
	/** Removes object from local storage */
	
	
	/*----------------------------------------------------------------------------------------
	* Block instantiation
	*---------------------------------------------------------------------------------------*/
		
	this.constructor.constructorErrorMessage = 'Interface ISerializable cannot be instantiated. Realize in derived classes.';
	
	throw new Error(this.constructor.constructorErrorMessage);
}



/*----------------------------------------------------------------------------------------
* Default methods (must be defined outside main function/class body)
*---------------------------------------------------------------------------------------*/


/** Automatically parses primitive private attributes in JSON object that have unified standard accessors, when instantiating class from JSON (i.e. called from within constructor).
*
* Re-referencing of more complex objects has to wait until this process has completed for all primary classes in the app, making the objects available in memory.
*
* Private attribute names must lead with a single underscore ('_'). Standard accessors have the same name as the attribute they set, except for removing any leading underscore. They can both set and get the value of the attribute, and manage basic validation and error handling. They must also be able to gracefully handle being passed a null.

* @param {Object} self Reference to the 'this' object in the calling class being instantiated

* @param {Object} json Representation in JSON format of the calling class being instantiated

* @param {String} class Name of the class being instantiated
*
* @param {Array} exclusions List of names of attributes to skip, e.g. because they cannot simply be set by calling an accessor
*
* @return true if succesfull, otherwise throws error
*
* @throws {ReferenceError} If JSON object does not have a valid ID
*
* @throws {TypeError} If JSON object is of the wrong class. (This may be redundant now that individual classes include the same check.)
*
* @todo Add handling of public, as well as private, attributes
*
* @todo Add unit test that tests this directly, rather than indirectly through its use by other classes
*/

app.ISerializable.prototype.default_parseParams = function(obj_json, str_class, arr_exlusions) {
	
	//self = this; // experimental, see if this references correctly
	
	var exclusions = arr_exlusions || []; exclusions.push('_constructor_');  exclusions.push('_id');
	
	
	if (!app[str_class]) {throw new TypeError('Class must be an app property that is a function');}
	
	
	function isPrimitive(str) {return ['boolean','undefined','number','string','symbol'].indexOf(str) > -1}
	
	
	if (obj_json._constructor_ === str_class) { // object has correct type
		
		if (parseInt(obj_json._id) === obj_json._id && obj_json._id > -1) { // object has valid ID
			
			for (var prop in obj_json) {
				
				if (exclusions.indexOf(prop) === -1) { // skip props in exclusions list
				
					// maybe call accessor on anything that has an underscore, and where accessor exists; might handle most complexes too
					
					if (obj_json[prop] === null || isPrimitive(typeof obj_json[prop])) {
					
						// call accessor (assumed have same name as property, except popping leading underscore)
						
						this[prop.slice(1)](obj_json[prop]); // primitive data type, call the property's accessor
					}
					
					// else: placeholder for complex data type (array or object), leave for re-referincing later
				}
				
				// else: in exclusions list, leave for custom logic to sort out
			}
		}
		
		else {
			
			throw new ReferenceError('Cannot re-instantiate object: ID not defined or not valid');
		}
	}
	
	else {
		
		throw new TypeError('Cannot re-instantiate object. Unexpected constructor: ' + obj_json._constructor_);
	}
	
	return true;
}


/** Writes object to local storage



*/

app.ISerializable.prototype.default_writeObject = function() {

	console.log(this._id);
	
	if (!localStorage) {
		
		throw new ReferenceError('localStorage not available');
	}
	
	else if (typeof app[str_class] !== 'function') {
		
		throw new TypeError('Class must be an app property that is a function');
	}
	
	var str_json;
	
	try {str_json = JSON.stringify(this)} catch(e) {throw new Error(e.message);}
	
	localStorage.setItem(app.prefs.localStoragePrefix() + str_class + '.' + this.id(), str_json);
	
	return true;
}